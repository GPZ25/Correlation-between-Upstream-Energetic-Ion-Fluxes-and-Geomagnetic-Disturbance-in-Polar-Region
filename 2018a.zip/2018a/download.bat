@echo off
rem download.bat: Download geomagnetic data from Edinburgh GIN

rem Configurable parameters - these variables control authentication
rem to the GIN web site and use of proxy servers at the users site -
rem change them as required (though the defaults should work OK)
set gin_username=
set gin_password=
set proxy_username=
set proxy_address=

rem check a download tool is available
set errmsg="Unable to find URL download software (curl or wget)"
call findtool
if %gmtool%==none goto :errhand

rem are we restarting a failed operation or starting from new
if not exist counter.bat goto D0
call counter.bat
goto D%gmcount%


:D0
echo Creating directories...
call safemd "2018"
call safemd "2018\AAE"
set errmsg="Unable to create directory: 2018\AAE"
if %gmstatus%==1 goto errhand
echo set gmcount=1 > counter.bat

:D1
call safemd "2018"
call safemd "2018\ABG"
set errmsg="Unable to create directory: 2018\ABG"
if %gmstatus%==1 goto errhand
echo set gmcount=2 > counter.bat

:D2
call safemd "2018"
call safemd "2018\ABK"
set errmsg="Unable to create directory: 2018\ABK"
if %gmstatus%==1 goto errhand
echo set gmcount=3 > counter.bat

:D3
call safemd "2018"
call safemd "2018\AIA"
set errmsg="Unable to create directory: 2018\AIA"
if %gmstatus%==1 goto errhand
echo set gmcount=4 > counter.bat

:D4
call safemd "2018"
call safemd "2018\ALE"
set errmsg="Unable to create directory: 2018\ALE"
if %gmstatus%==1 goto errhand
echo set gmcount=5 > counter.bat

:D5
call safemd "2018"
call safemd "2018\AMS"
set errmsg="Unable to create directory: 2018\AMS"
if %gmstatus%==1 goto errhand
echo set gmcount=6 > counter.bat

:D6
call safemd "2018"
call safemd "2018\API"
set errmsg="Unable to create directory: 2018\API"
if %gmstatus%==1 goto errhand
echo set gmcount=7 > counter.bat

:D7
call safemd "2018"
call safemd "2018\AQU"
set errmsg="Unable to create directory: 2018\AQU"
if %gmstatus%==1 goto errhand
echo set gmcount=8 > counter.bat

:D8
call safemd "2018"
call safemd "2018\ARS"
set errmsg="Unable to create directory: 2018\ARS"
if %gmstatus%==1 goto errhand
echo set gmcount=9 > counter.bat

:D9
call safemd "2018"
call safemd "2018\ASC"
set errmsg="Unable to create directory: 2018\ASC"
if %gmstatus%==1 goto errhand
echo set gmcount=10 > counter.bat

:D10
call safemd "2018"
call safemd "2018\ASP"
set errmsg="Unable to create directory: 2018\ASP"
if %gmstatus%==1 goto errhand
echo set gmcount=11 > counter.bat

:D11
call safemd "2018"
call safemd "2018\BDV"
set errmsg="Unable to create directory: 2018\BDV"
if %gmstatus%==1 goto errhand
echo set gmcount=12 > counter.bat

:D12
call safemd "2018"
call safemd "2018\BEL"
set errmsg="Unable to create directory: 2018\BEL"
if %gmstatus%==1 goto errhand
echo set gmcount=13 > counter.bat

:D13
call safemd "2018"
call safemd "2018\BFE"
set errmsg="Unable to create directory: 2018\BFE"
if %gmstatus%==1 goto errhand
echo set gmcount=14 > counter.bat

:D14
call safemd "2018"
call safemd "2018\BFO"
set errmsg="Unable to create directory: 2018\BFO"
if %gmstatus%==1 goto errhand
echo set gmcount=15 > counter.bat

:D15
call safemd "2018"
call safemd "2018\BLC"
set errmsg="Unable to create directory: 2018\BLC"
if %gmstatus%==1 goto errhand
echo set gmcount=16 > counter.bat

:D16
call safemd "2018"
call safemd "2018\BMT"
set errmsg="Unable to create directory: 2018\BMT"
if %gmstatus%==1 goto errhand
echo set gmcount=17 > counter.bat

:D17
call safemd "2018"
call safemd "2018\BNG"
set errmsg="Unable to create directory: 2018\BNG"
if %gmstatus%==1 goto errhand
echo set gmcount=18 > counter.bat

:D18
call safemd "2018"
call safemd "2018\BOU"
set errmsg="Unable to create directory: 2018\BOU"
if %gmstatus%==1 goto errhand
echo set gmcount=19 > counter.bat

:D19
call safemd "2018"
call safemd "2018\BOX"
set errmsg="Unable to create directory: 2018\BOX"
if %gmstatus%==1 goto errhand
echo set gmcount=20 > counter.bat

:D20
call safemd "2018"
call safemd "2018\BRD"
set errmsg="Unable to create directory: 2018\BRD"
if %gmstatus%==1 goto errhand
echo set gmcount=21 > counter.bat

:D21
call safemd "2018"
call safemd "2018\BRW"
set errmsg="Unable to create directory: 2018\BRW"
if %gmstatus%==1 goto errhand
echo set gmcount=22 > counter.bat

:D22
call safemd "2018"
call safemd "2018\BSL"
set errmsg="Unable to create directory: 2018\BSL"
if %gmstatus%==1 goto errhand
echo set gmcount=23 > counter.bat

:D23
call safemd "2018"
call safemd "2018\CBB"
set errmsg="Unable to create directory: 2018\CBB"
if %gmstatus%==1 goto errhand
echo set gmcount=24 > counter.bat

:D24
call safemd "2018"
call safemd "2018\CKI"
set errmsg="Unable to create directory: 2018\CKI"
if %gmstatus%==1 goto errhand
echo set gmcount=25 > counter.bat

:D25
call safemd "2018"
call safemd "2018\CLF"
set errmsg="Unable to create directory: 2018\CLF"
if %gmstatus%==1 goto errhand
echo set gmcount=26 > counter.bat

:D26
call safemd "2018"
call safemd "2018\CMO"
set errmsg="Unable to create directory: 2018\CMO"
if %gmstatus%==1 goto errhand
echo set gmcount=27 > counter.bat

:D27
call safemd "2018"
call safemd "2018\CNB"
set errmsg="Unable to create directory: 2018\CNB"
if %gmstatus%==1 goto errhand
echo set gmcount=28 > counter.bat

:D28
call safemd "2018"
call safemd "2018\CNH"
set errmsg="Unable to create directory: 2018\CNH"
if %gmstatus%==1 goto errhand
echo set gmcount=29 > counter.bat

:D29
call safemd "2018"
call safemd "2018\CPL"
set errmsg="Unable to create directory: 2018\CPL"
if %gmstatus%==1 goto errhand
echo set gmcount=30 > counter.bat

:D30
call safemd "2018"
call safemd "2018\CSY"
set errmsg="Unable to create directory: 2018\CSY"
if %gmstatus%==1 goto errhand
echo set gmcount=31 > counter.bat

:D31
call safemd "2018"
call safemd "2018\CTA"
set errmsg="Unable to create directory: 2018\CTA"
if %gmstatus%==1 goto errhand
echo set gmcount=32 > counter.bat

:D32
call safemd "2018"
call safemd "2018\CYG"
set errmsg="Unable to create directory: 2018\CYG"
if %gmstatus%==1 goto errhand
echo set gmcount=33 > counter.bat

:D33
call safemd "2018"
call safemd "2018\CZT"
set errmsg="Unable to create directory: 2018\CZT"
if %gmstatus%==1 goto errhand
echo set gmcount=34 > counter.bat

:D34
call safemd "2018"
call safemd "2018\DED"
set errmsg="Unable to create directory: 2018\DED"
if %gmstatus%==1 goto errhand
echo set gmcount=35 > counter.bat

:D35
call safemd "2018"
call safemd "2018\DLR"
set errmsg="Unable to create directory: 2018\DLR"
if %gmstatus%==1 goto errhand
echo set gmcount=36 > counter.bat

:D36
call safemd "2018"
call safemd "2018\DLT"
set errmsg="Unable to create directory: 2018\DLT"
if %gmstatus%==1 goto errhand
echo set gmcount=37 > counter.bat

:D37
call safemd "2018"
call safemd "2018\DMC"
set errmsg="Unable to create directory: 2018\DMC"
if %gmstatus%==1 goto errhand
echo set gmcount=38 > counter.bat

:D38
call safemd "2018"
call safemd "2018\DOU"
set errmsg="Unable to create directory: 2018\DOU"
if %gmstatus%==1 goto errhand
echo set gmcount=39 > counter.bat

:D39
call safemd "2018"
call safemd "2018\DRV"
set errmsg="Unable to create directory: 2018\DRV"
if %gmstatus%==1 goto errhand
echo set gmcount=40 > counter.bat

:D40
call safemd "2018"
call safemd "2018\DUR"
set errmsg="Unable to create directory: 2018\DUR"
if %gmstatus%==1 goto errhand
echo set gmcount=41 > counter.bat

:D41
call safemd "2018"
call safemd "2018\EBR"
set errmsg="Unable to create directory: 2018\EBR"
if %gmstatus%==1 goto errhand
echo set gmcount=42 > counter.bat

:D42
call safemd "2018"
call safemd "2018\ESK"
set errmsg="Unable to create directory: 2018\ESK"
if %gmstatus%==1 goto errhand
echo set gmcount=43 > counter.bat

:D43
call safemd "2018"
call safemd "2018\EYR"
set errmsg="Unable to create directory: 2018\EYR"
if %gmstatus%==1 goto errhand
echo set gmcount=44 > counter.bat

:D44
call safemd "2018"
call safemd "2018\FCC"
set errmsg="Unable to create directory: 2018\FCC"
if %gmstatus%==1 goto errhand
echo set gmcount=45 > counter.bat

:D45
call safemd "2018"
call safemd "2018\FRD"
set errmsg="Unable to create directory: 2018\FRD"
if %gmstatus%==1 goto errhand
echo set gmcount=46 > counter.bat

:D46
call safemd "2018"
call safemd "2018\FRN"
set errmsg="Unable to create directory: 2018\FRN"
if %gmstatus%==1 goto errhand
echo set gmcount=47 > counter.bat

:D47
call safemd "2018"
call safemd "2018\FUR"
set errmsg="Unable to create directory: 2018\FUR"
if %gmstatus%==1 goto errhand
echo set gmcount=48 > counter.bat

:D48
call safemd "2018"
call safemd "2018\GAN"
set errmsg="Unable to create directory: 2018\GAN"
if %gmstatus%==1 goto errhand
echo set gmcount=49 > counter.bat

:D49
call safemd "2018"
call safemd "2018\GCK"
set errmsg="Unable to create directory: 2018\GCK"
if %gmstatus%==1 goto errhand
echo set gmcount=50 > counter.bat

:D50
call safemd "2018"
call safemd "2018\GDH"
set errmsg="Unable to create directory: 2018\GDH"
if %gmstatus%==1 goto errhand
echo set gmcount=51 > counter.bat

:D51
call safemd "2018"
call safemd "2018\GLN"
set errmsg="Unable to create directory: 2018\GLN"
if %gmstatus%==1 goto errhand
echo set gmcount=52 > counter.bat

:D52
call safemd "2018"
call safemd "2018\GNA"
set errmsg="Unable to create directory: 2018\GNA"
if %gmstatus%==1 goto errhand
echo set gmcount=53 > counter.bat

:D53
call safemd "2018"
call safemd "2018\GNG"
set errmsg="Unable to create directory: 2018\GNG"
if %gmstatus%==1 goto errhand
echo set gmcount=54 > counter.bat

:D54
call safemd "2018"
call safemd "2018\GUA"
set errmsg="Unable to create directory: 2018\GUA"
if %gmstatus%==1 goto errhand
echo set gmcount=55 > counter.bat

:D55
call safemd "2018"
call safemd "2018\GUI"
set errmsg="Unable to create directory: 2018\GUI"
if %gmstatus%==1 goto errhand
echo set gmcount=56 > counter.bat

:D56
call safemd "2018"
call safemd "2018\GZH"
set errmsg="Unable to create directory: 2018\GZH"
if %gmstatus%==1 goto errhand
echo set gmcount=57 > counter.bat

:D57
call safemd "2018"
call safemd "2018\HAD"
set errmsg="Unable to create directory: 2018\HAD"
if %gmstatus%==1 goto errhand
echo set gmcount=58 > counter.bat

:D58
call safemd "2018"
call safemd "2018\HBK"
set errmsg="Unable to create directory: 2018\HBK"
if %gmstatus%==1 goto errhand
echo set gmcount=59 > counter.bat

:D59
call safemd "2018"
call safemd "2018\HER"
set errmsg="Unable to create directory: 2018\HER"
if %gmstatus%==1 goto errhand
echo set gmcount=60 > counter.bat

:D60
call safemd "2018"
call safemd "2018\HLP"
set errmsg="Unable to create directory: 2018\HLP"
if %gmstatus%==1 goto errhand
echo set gmcount=61 > counter.bat

:D61
call safemd "2018"
call safemd "2018\HON"
set errmsg="Unable to create directory: 2018\HON"
if %gmstatus%==1 goto errhand
echo set gmcount=62 > counter.bat

:D62
call safemd "2018"
call safemd "2018\HRB"
set errmsg="Unable to create directory: 2018\HRB"
if %gmstatus%==1 goto errhand
echo set gmcount=63 > counter.bat

:D63
call safemd "2018"
call safemd "2018\HRN"
set errmsg="Unable to create directory: 2018\HRN"
if %gmstatus%==1 goto errhand
echo set gmcount=64 > counter.bat

:D64
call safemd "2018"
call safemd "2018\HUA"
set errmsg="Unable to create directory: 2018\HUA"
if %gmstatus%==1 goto errhand
echo set gmcount=65 > counter.bat

:D65
call safemd "2018"
call safemd "2018\HYB"
set errmsg="Unable to create directory: 2018\HYB"
if %gmstatus%==1 goto errhand
echo set gmcount=66 > counter.bat

:D66
call safemd "2018"
call safemd "2018\IPM"
set errmsg="Unable to create directory: 2018\IPM"
if %gmstatus%==1 goto errhand
echo set gmcount=67 > counter.bat

:D67
call safemd "2018"
call safemd "2018\IQA"
set errmsg="Unable to create directory: 2018\IQA"
if %gmstatus%==1 goto errhand
echo set gmcount=68 > counter.bat

:D68
call safemd "2018"
call safemd "2018\IRT"
set errmsg="Unable to create directory: 2018\IRT"
if %gmstatus%==1 goto errhand
echo set gmcount=69 > counter.bat

:D69
call safemd "2018"
call safemd "2018\ISK"
set errmsg="Unable to create directory: 2018\ISK"
if %gmstatus%==1 goto errhand
echo set gmcount=70 > counter.bat

:D70
call safemd "2018"
call safemd "2018\IZN"
set errmsg="Unable to create directory: 2018\IZN"
if %gmstatus%==1 goto errhand
echo set gmcount=71 > counter.bat

:D71
call safemd "2018"
call safemd "2018\JAI"
set errmsg="Unable to create directory: 2018\JAI"
if %gmstatus%==1 goto errhand
echo set gmcount=72 > counter.bat

:D72
call safemd "2018"
call safemd "2018\JCO"
set errmsg="Unable to create directory: 2018\JCO"
if %gmstatus%==1 goto errhand
echo set gmcount=73 > counter.bat

:D73
call safemd "2018"
call safemd "2018\KAK"
set errmsg="Unable to create directory: 2018\KAK"
if %gmstatus%==1 goto errhand
echo set gmcount=74 > counter.bat

:D74
call safemd "2018"
call safemd "2018\KDU"
set errmsg="Unable to create directory: 2018\KDU"
if %gmstatus%==1 goto errhand
echo set gmcount=75 > counter.bat

:D75
call safemd "2018"
call safemd "2018\KEP"
set errmsg="Unable to create directory: 2018\KEP"
if %gmstatus%==1 goto errhand
echo set gmcount=76 > counter.bat

:D76
call safemd "2018"
call safemd "2018\KHB"
set errmsg="Unable to create directory: 2018\KHB"
if %gmstatus%==1 goto errhand
echo set gmcount=77 > counter.bat

:D77
call safemd "2018"
call safemd "2018\KIR"
set errmsg="Unable to create directory: 2018\KIR"
if %gmstatus%==1 goto errhand
echo set gmcount=78 > counter.bat

:D78
call safemd "2018"
call safemd "2018\KIV"
set errmsg="Unable to create directory: 2018\KIV"
if %gmstatus%==1 goto errhand
echo set gmcount=79 > counter.bat

:D79
call safemd "2018"
call safemd "2018\KMH"
set errmsg="Unable to create directory: 2018\KMH"
if %gmstatus%==1 goto errhand
echo set gmcount=80 > counter.bat

:D80
call safemd "2018"
call safemd "2018\KNY"
set errmsg="Unable to create directory: 2018\KNY"
if %gmstatus%==1 goto errhand
echo set gmcount=81 > counter.bat

:D81
call safemd "2018"
call safemd "2018\KOU"
set errmsg="Unable to create directory: 2018\KOU"
if %gmstatus%==1 goto errhand
echo set gmcount=82 > counter.bat

:D82
call safemd "2018"
call safemd "2018\LER"
set errmsg="Unable to create directory: 2018\LER"
if %gmstatus%==1 goto errhand
echo set gmcount=83 > counter.bat

:D83
call safemd "2018"
call safemd "2018\LNP"
set errmsg="Unable to create directory: 2018\LNP"
if %gmstatus%==1 goto errhand
echo set gmcount=84 > counter.bat

:D84
call safemd "2018"
call safemd "2018\LON"
set errmsg="Unable to create directory: 2018\LON"
if %gmstatus%==1 goto errhand
echo set gmcount=85 > counter.bat

:D85
call safemd "2018"
call safemd "2018\LOV"
set errmsg="Unable to create directory: 2018\LOV"
if %gmstatus%==1 goto errhand
echo set gmcount=86 > counter.bat

:D86
call safemd "2018"
call safemd "2018\LRM"
set errmsg="Unable to create directory: 2018\LRM"
if %gmstatus%==1 goto errhand
echo set gmcount=87 > counter.bat

:D87
call safemd "2018"
call safemd "2018\LVV"
set errmsg="Unable to create directory: 2018\LVV"
if %gmstatus%==1 goto errhand
echo set gmcount=88 > counter.bat

:D88
call safemd "2018"
call safemd "2018\LYC"
set errmsg="Unable to create directory: 2018\LYC"
if %gmstatus%==1 goto errhand
echo set gmcount=89 > counter.bat

:D89
call safemd "2018"
call safemd "2018\LZH"
set errmsg="Unable to create directory: 2018\LZH"
if %gmstatus%==1 goto errhand
echo set gmcount=90 > counter.bat

:D90
call safemd "2018"
call safemd "2018\MAB"
set errmsg="Unable to create directory: 2018\MAB"
if %gmstatus%==1 goto errhand
echo set gmcount=91 > counter.bat

:D91
call safemd "2018"
call safemd "2018\MAW"
set errmsg="Unable to create directory: 2018\MAW"
if %gmstatus%==1 goto errhand
echo set gmcount=92 > counter.bat

:D92
call safemd "2018"
call safemd "2018\MBC"
set errmsg="Unable to create directory: 2018\MBC"
if %gmstatus%==1 goto errhand
echo set gmcount=93 > counter.bat

:D93
call safemd "2018"
call safemd "2018\MBO"
set errmsg="Unable to create directory: 2018\MBO"
if %gmstatus%==1 goto errhand
echo set gmcount=94 > counter.bat

:D94
call safemd "2018"
call safemd "2018\MCQ"
set errmsg="Unable to create directory: 2018\MCQ"
if %gmstatus%==1 goto errhand
echo set gmcount=95 > counter.bat

:D95
call safemd "2018"
call safemd "2018\MEA"
set errmsg="Unable to create directory: 2018\MEA"
if %gmstatus%==1 goto errhand
echo set gmcount=96 > counter.bat

:D96
call safemd "2018"
call safemd "2018\MGD"
set errmsg="Unable to create directory: 2018\MGD"
if %gmstatus%==1 goto errhand
echo set gmcount=97 > counter.bat

:D97
call safemd "2018"
call safemd "2018\MID"
set errmsg="Unable to create directory: 2018\MID"
if %gmstatus%==1 goto errhand
echo set gmcount=98 > counter.bat

:D98
call safemd "2018"
call safemd "2018\MLT"
set errmsg="Unable to create directory: 2018\MLT"
if %gmstatus%==1 goto errhand
echo set gmcount=99 > counter.bat

:D99
call safemd "2018"
call safemd "2018\MMB"
set errmsg="Unable to create directory: 2018\MMB"
if %gmstatus%==1 goto errhand
echo set gmcount=100 > counter.bat

:D100
call safemd "2018"
call safemd "2018\MZL"
set errmsg="Unable to create directory: 2018\MZL"
if %gmstatus%==1 goto errhand
echo set gmcount=101 > counter.bat

:D101
call safemd "2018"
call safemd "2018\NAQ"
set errmsg="Unable to create directory: 2018\NAQ"
if %gmstatus%==1 goto errhand
echo set gmcount=102 > counter.bat

:D102
call safemd "2018"
call safemd "2018\NCK"
set errmsg="Unable to create directory: 2018\NCK"
if %gmstatus%==1 goto errhand
echo set gmcount=103 > counter.bat

:D103
call safemd "2018"
call safemd "2018\NEW"
set errmsg="Unable to create directory: 2018\NEW"
if %gmstatus%==1 goto errhand
echo set gmcount=104 > counter.bat

:D104
call safemd "2018"
call safemd "2018\NGK"
set errmsg="Unable to create directory: 2018\NGK"
if %gmstatus%==1 goto errhand
echo set gmcount=105 > counter.bat

:D105
call safemd "2018"
call safemd "2018\NUR"
set errmsg="Unable to create directory: 2018\NUR"
if %gmstatus%==1 goto errhand
echo set gmcount=106 > counter.bat

:D106
call safemd "2018"
call safemd "2018\NVS"
set errmsg="Unable to create directory: 2018\NVS"
if %gmstatus%==1 goto errhand
echo set gmcount=107 > counter.bat

:D107
call safemd "2018"
call safemd "2018\ORC"
set errmsg="Unable to create directory: 2018\ORC"
if %gmstatus%==1 goto errhand
echo set gmcount=108 > counter.bat

:D108
call safemd "2018"
call safemd "2018\OTT"
set errmsg="Unable to create directory: 2018\OTT"
if %gmstatus%==1 goto errhand
echo set gmcount=109 > counter.bat

:D109
call safemd "2018"
call safemd "2018\PAF"
set errmsg="Unable to create directory: 2018\PAF"
if %gmstatus%==1 goto errhand
echo set gmcount=110 > counter.bat

:D110
call safemd "2018"
call safemd "2018\PAG"
set errmsg="Unable to create directory: 2018\PAG"
if %gmstatus%==1 goto errhand
echo set gmcount=111 > counter.bat

:D111
call safemd "2018"
call safemd "2018\PBQ"
set errmsg="Unable to create directory: 2018\PBQ"
if %gmstatus%==1 goto errhand
echo set gmcount=112 > counter.bat

:D112
call safemd "2018"
call safemd "2018\PEG"
set errmsg="Unable to create directory: 2018\PEG"
if %gmstatus%==1 goto errhand
echo set gmcount=113 > counter.bat

:D113
call safemd "2018"
call safemd "2018\PET"
set errmsg="Unable to create directory: 2018\PET"
if %gmstatus%==1 goto errhand
echo set gmcount=114 > counter.bat

:D114
call safemd "2018"
call safemd "2018\PHU"
set errmsg="Unable to create directory: 2018\PHU"
if %gmstatus%==1 goto errhand
echo set gmcount=115 > counter.bat

:D115
call safemd "2018"
call safemd "2018\PIL"
set errmsg="Unable to create directory: 2018\PIL"
if %gmstatus%==1 goto errhand
echo set gmcount=116 > counter.bat

:D116
call safemd "2018"
call safemd "2018\PPT"
set errmsg="Unable to create directory: 2018\PPT"
if %gmstatus%==1 goto errhand
echo set gmcount=117 > counter.bat

:D117
call safemd "2018"
call safemd "2018\PST"
set errmsg="Unable to create directory: 2018\PST"
if %gmstatus%==1 goto errhand
echo set gmcount=118 > counter.bat

:D118
call safemd "2018"
call safemd "2018\QSB"
set errmsg="Unable to create directory: 2018\QSB"
if %gmstatus%==1 goto errhand
echo set gmcount=119 > counter.bat

:D119
call safemd "2018"
call safemd "2018\RES"
set errmsg="Unable to create directory: 2018\RES"
if %gmstatus%==1 goto errhand
echo set gmcount=120 > counter.bat

:D120
call safemd "2018"
call safemd "2018\REU"
set errmsg="Unable to create directory: 2018\REU"
if %gmstatus%==1 goto errhand
echo set gmcount=121 > counter.bat

:D121
call safemd "2018"
call safemd "2018\SBA"
set errmsg="Unable to create directory: 2018\SBA"
if %gmstatus%==1 goto errhand
echo set gmcount=122 > counter.bat

:D122
call safemd "2018"
call safemd "2018\SBL"
set errmsg="Unable to create directory: 2018\SBL"
if %gmstatus%==1 goto errhand
echo set gmcount=123 > counter.bat

:D123
call safemd "2018"
call safemd "2018\SFS"
set errmsg="Unable to create directory: 2018\SFS"
if %gmstatus%==1 goto errhand
echo set gmcount=124 > counter.bat

:D124
call safemd "2018"
call safemd "2018\SHE"
set errmsg="Unable to create directory: 2018\SHE"
if %gmstatus%==1 goto errhand
echo set gmcount=125 > counter.bat

:D125
call safemd "2018"
call safemd "2018\SHU"
set errmsg="Unable to create directory: 2018\SHU"
if %gmstatus%==1 goto errhand
echo set gmcount=126 > counter.bat

:D126
call safemd "2018"
call safemd "2018\SIT"
set errmsg="Unable to create directory: 2018\SIT"
if %gmstatus%==1 goto errhand
echo set gmcount=127 > counter.bat

:D127
call safemd "2018"
call safemd "2018\SJG"
set errmsg="Unable to create directory: 2018\SJG"
if %gmstatus%==1 goto errhand
echo set gmcount=128 > counter.bat

:D128
call safemd "2018"
call safemd "2018\SOD"
set errmsg="Unable to create directory: 2018\SOD"
if %gmstatus%==1 goto errhand
echo set gmcount=129 > counter.bat

:D129
call safemd "2018"
call safemd "2018\SPG"
set errmsg="Unable to create directory: 2018\SPG"
if %gmstatus%==1 goto errhand
echo set gmcount=130 > counter.bat

:D130
call safemd "2018"
call safemd "2018\SPT"
set errmsg="Unable to create directory: 2018\SPT"
if %gmstatus%==1 goto errhand
echo set gmcount=131 > counter.bat

:D131
call safemd "2018"
call safemd "2018\STJ"
set errmsg="Unable to create directory: 2018\STJ"
if %gmstatus%==1 goto errhand
echo set gmcount=132 > counter.bat

:D132
call safemd "2018"
call safemd "2018\STT"
set errmsg="Unable to create directory: 2018\STT"
if %gmstatus%==1 goto errhand
echo set gmcount=133 > counter.bat

:D133
call safemd "2018"
call safemd "2018\SUA"
set errmsg="Unable to create directory: 2018\SUA"
if %gmstatus%==1 goto errhand
echo set gmcount=134 > counter.bat

:D134
call safemd "2018"
call safemd "2018\TAM"
set errmsg="Unable to create directory: 2018\TAM"
if %gmstatus%==1 goto errhand
echo set gmcount=135 > counter.bat

:D135
call safemd "2018"
call safemd "2018\TAN"
set errmsg="Unable to create directory: 2018\TAN"
if %gmstatus%==1 goto errhand
echo set gmcount=136 > counter.bat

:D136
call safemd "2018"
call safemd "2018\TDC"
set errmsg="Unable to create directory: 2018\TDC"
if %gmstatus%==1 goto errhand
echo set gmcount=137 > counter.bat

:D137
call safemd "2018"
call safemd "2018\THL"
set errmsg="Unable to create directory: 2018\THL"
if %gmstatus%==1 goto errhand
echo set gmcount=138 > counter.bat

:D138
call safemd "2018"
call safemd "2018\THY"
set errmsg="Unable to create directory: 2018\THY"
if %gmstatus%==1 goto errhand
echo set gmcount=139 > counter.bat

:D139
call safemd "2018"
call safemd "2018\TIK"
set errmsg="Unable to create directory: 2018\TIK"
if %gmstatus%==1 goto errhand
echo set gmcount=140 > counter.bat

:D140
call safemd "2018"
call safemd "2018\TSU"
set errmsg="Unable to create directory: 2018\TSU"
if %gmstatus%==1 goto errhand
echo set gmcount=141 > counter.bat

:D141
call safemd "2018"
call safemd "2018\TTB"
set errmsg="Unable to create directory: 2018\TTB"
if %gmstatus%==1 goto errhand
echo set gmcount=142 > counter.bat

:D142
call safemd "2018"
call safemd "2018\TUC"
set errmsg="Unable to create directory: 2018\TUC"
if %gmstatus%==1 goto errhand
echo set gmcount=143 > counter.bat

:D143
call safemd "2018"
call safemd "2018\UPS"
set errmsg="Unable to create directory: 2018\UPS"
if %gmstatus%==1 goto errhand
echo set gmcount=144 > counter.bat

:D144
call safemd "2018"
call safemd "2018\VAL"
set errmsg="Unable to create directory: 2018\VAL"
if %gmstatus%==1 goto errhand
echo set gmcount=145 > counter.bat

:D145
call safemd "2018"
call safemd "2018\VIC"
set errmsg="Unable to create directory: 2018\VIC"
if %gmstatus%==1 goto errhand
echo set gmcount=146 > counter.bat

:D146
call safemd "2018"
call safemd "2018\VNA"
set errmsg="Unable to create directory: 2018\VNA"
if %gmstatus%==1 goto errhand
echo set gmcount=147 > counter.bat

:D147
call safemd "2018"
call safemd "2018\VOS"
set errmsg="Unable to create directory: 2018\VOS"
if %gmstatus%==1 goto errhand
echo set gmcount=148 > counter.bat

:D148
call safemd "2018"
call safemd "2018\VSS"
set errmsg="Unable to create directory: 2018\VSS"
if %gmstatus%==1 goto errhand
echo set gmcount=149 > counter.bat

:D149
call safemd "2018"
call safemd "2018\WIC"
set errmsg="Unable to create directory: 2018\WIC"
if %gmstatus%==1 goto errhand
echo set gmcount=150 > counter.bat

:D150
call safemd "2018"
call safemd "2018\WMQ"
set errmsg="Unable to create directory: 2018\WMQ"
if %gmstatus%==1 goto errhand
echo set gmcount=151 > counter.bat

:D151
call safemd "2018"
call safemd "2018\WNG"
set errmsg="Unable to create directory: 2018\WNG"
if %gmstatus%==1 goto errhand
echo set gmcount=152 > counter.bat

:D152
call safemd "2018"
call safemd "2018\YAK"
set errmsg="Unable to create directory: 2018\YAK"
if %gmstatus%==1 goto errhand
echo set gmcount=153 > counter.bat

:D153
call safemd "2018"
call safemd "2018\YKC"
set errmsg="Unable to create directory: 2018\YKC"
if %gmstatus%==1 goto errhand
echo set gmcount=154 > counter.bat

:D154
echo 0%% - downloading file: 2018\AAE\aae20180118dmin.min
set errmsg="Unable to download 2018\AAE\aae20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=AAE&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\AAE\aae20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=155 > counter.bat

:D155
echo 0%% - downloading file: 2018\ABG\abg20180118dmin.min
set errmsg="Unable to download 2018\ABG\abg20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ABG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ABG\abg20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=156 > counter.bat

:D156
echo 1%% - downloading file: 2018\ABK\abk20180118dmin.min
set errmsg="Unable to download 2018\ABK\abk20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ABK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ABK\abk20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=157 > counter.bat

:D157
echo 1%% - downloading file: 2018\AIA\aia20180118dmin.min
set errmsg="Unable to download 2018\AIA\aia20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=AIA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\AIA\aia20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=158 > counter.bat

:D158
echo 2%% - downloading file: 2018\ALE\ale20180118dmin.min
set errmsg="Unable to download 2018\ALE\ale20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ALE&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ALE\ale20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=159 > counter.bat

:D159
echo 3%% - downloading file: 2018\AMS\ams20180118dmin.min
set errmsg="Unable to download 2018\AMS\ams20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=AMS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\AMS\ams20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=160 > counter.bat

:D160
echo 3%% - downloading file: 2018\API\api20180118dmin.min
set errmsg="Unable to download 2018\API\api20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=API&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\API\api20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=161 > counter.bat

:D161
echo 4%% - downloading file: 2018\AQU\aqu20180118dmin.min
set errmsg="Unable to download 2018\AQU\aqu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=AQU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\AQU\aqu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=162 > counter.bat

:D162
echo 5%% - downloading file: 2018\ARS\ars20180118dmin.min
set errmsg="Unable to download 2018\ARS\ars20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ARS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ARS\ars20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=163 > counter.bat

:D163
echo 5%% - downloading file: 2018\ASC\asc20180118dmin.min
set errmsg="Unable to download 2018\ASC\asc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ASC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ASC\asc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=164 > counter.bat

:D164
echo 6%% - downloading file: 2018\ASP\asp20180118dmin.min
set errmsg="Unable to download 2018\ASP\asp20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ASP&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ASP\asp20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=165 > counter.bat

:D165
echo 7%% - downloading file: 2018\BDV\bdv20180118dmin.min
set errmsg="Unable to download 2018\BDV\bdv20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BDV&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BDV\bdv20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=166 > counter.bat

:D166
echo 7%% - downloading file: 2018\BEL\bel20180118dmin.min
set errmsg="Unable to download 2018\BEL\bel20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BEL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BEL\bel20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=167 > counter.bat

:D167
echo 8%% - downloading file: 2018\BFE\bfe20180118dmin.min
set errmsg="Unable to download 2018\BFE\bfe20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BFE&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BFE\bfe20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=168 > counter.bat

:D168
echo 9%% - downloading file: 2018\BFO\bfo20180118dmin.min
set errmsg="Unable to download 2018\BFO\bfo20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BFO&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BFO\bfo20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=169 > counter.bat

:D169
echo 9%% - downloading file: 2018\BLC\blc20180118dmin.min
set errmsg="Unable to download 2018\BLC\blc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BLC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BLC\blc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=170 > counter.bat

:D170
echo 10%% - downloading file: 2018\BMT\bmt20180118dmin.min
set errmsg="Unable to download 2018\BMT\bmt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BMT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BMT\bmt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=171 > counter.bat

:D171
echo 11%% - downloading file: 2018\BNG\bng20180118dmin.min
set errmsg="Unable to download 2018\BNG\bng20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BNG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BNG\bng20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=172 > counter.bat

:D172
echo 11%% - downloading file: 2018\BOU\bou20180118dmin.min
set errmsg="Unable to download 2018\BOU\bou20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BOU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BOU\bou20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=173 > counter.bat

:D173
echo 12%% - downloading file: 2018\BOX\box20180118dmin.min
set errmsg="Unable to download 2018\BOX\box20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BOX&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BOX\box20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=174 > counter.bat

:D174
echo 12%% - downloading file: 2018\BRD\brd20180118dmin.min
set errmsg="Unable to download 2018\BRD\brd20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BRD&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BRD\brd20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=175 > counter.bat

:D175
echo 13%% - downloading file: 2018\BRW\brw20180118dmin.min
set errmsg="Unable to download 2018\BRW\brw20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BRW&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BRW\brw20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=176 > counter.bat

:D176
echo 14%% - downloading file: 2018\BSL\bsl20180118dmin.min
set errmsg="Unable to download 2018\BSL\bsl20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=BSL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\BSL\bsl20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=177 > counter.bat

:D177
echo 14%% - downloading file: 2018\CBB\cbb20180118dmin.min
set errmsg="Unable to download 2018\CBB\cbb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CBB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CBB\cbb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=178 > counter.bat

:D178
echo 15%% - downloading file: 2018\CKI\cki20180118dmin.min
set errmsg="Unable to download 2018\CKI\cki20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CKI&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CKI\cki20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=179 > counter.bat

:D179
echo 16%% - downloading file: 2018\CLF\clf20180118dmin.min
set errmsg="Unable to download 2018\CLF\clf20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CLF&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CLF\clf20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=180 > counter.bat

:D180
echo 16%% - downloading file: 2018\CMO\cmo20180118dmin.min
set errmsg="Unable to download 2018\CMO\cmo20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CMO&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CMO\cmo20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=181 > counter.bat

:D181
echo 17%% - downloading file: 2018\CNB\cnb20180118dmin.min
set errmsg="Unable to download 2018\CNB\cnb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CNB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CNB\cnb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=182 > counter.bat

:D182
echo 18%% - downloading file: 2018\CNH\cnh20180118dmin.min
set errmsg="Unable to download 2018\CNH\cnh20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CNH&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CNH\cnh20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=183 > counter.bat

:D183
echo 18%% - downloading file: 2018\CPL\cpl20180118dmin.min
set errmsg="Unable to download 2018\CPL\cpl20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CPL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CPL\cpl20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=184 > counter.bat

:D184
echo 19%% - downloading file: 2018\CSY\csy20180118dmin.min
set errmsg="Unable to download 2018\CSY\csy20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CSY&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CSY\csy20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=185 > counter.bat

:D185
echo 20%% - downloading file: 2018\CTA\cta20180118dmin.min
set errmsg="Unable to download 2018\CTA\cta20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CTA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CTA\cta20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=186 > counter.bat

:D186
echo 20%% - downloading file: 2018\CYG\cyg20180118dmin.min
set errmsg="Unable to download 2018\CYG\cyg20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CYG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CYG\cyg20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=187 > counter.bat

:D187
echo 21%% - downloading file: 2018\CZT\czt20180118dmin.min
set errmsg="Unable to download 2018\CZT\czt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=CZT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\CZT\czt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=188 > counter.bat

:D188
echo 22%% - downloading file: 2018\DED\ded20180118dmin.min
set errmsg="Unable to download 2018\DED\ded20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DED&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DED\ded20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=189 > counter.bat

:D189
echo 22%% - downloading file: 2018\DLR\dlr20180118dmin.min
set errmsg="Unable to download 2018\DLR\dlr20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DLR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DLR\dlr20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=190 > counter.bat

:D190
echo 23%% - downloading file: 2018\DLT\dlt20180118dmin.min
set errmsg="Unable to download 2018\DLT\dlt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DLT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DLT\dlt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=191 > counter.bat

:D191
echo 24%% - downloading file: 2018\DMC\dmc20180118dmin.min
set errmsg="Unable to download 2018\DMC\dmc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DMC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DMC\dmc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=192 > counter.bat

:D192
echo 24%% - downloading file: 2018\DOU\dou20180118dmin.min
set errmsg="Unable to download 2018\DOU\dou20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DOU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DOU\dou20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=193 > counter.bat

:D193
echo 25%% - downloading file: 2018\DRV\drv20180118dmin.min
set errmsg="Unable to download 2018\DRV\drv20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DRV&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DRV\drv20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=194 > counter.bat

:D194
echo 25%% - downloading file: 2018\DUR\dur20180118dmin.min
set errmsg="Unable to download 2018\DUR\dur20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=DUR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\DUR\dur20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=195 > counter.bat

:D195
echo 26%% - downloading file: 2018\EBR\ebr20180118dmin.min
set errmsg="Unable to download 2018\EBR\ebr20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=EBR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\EBR\ebr20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=196 > counter.bat

:D196
echo 27%% - downloading file: 2018\ESK\esk20180118dmin.min
set errmsg="Unable to download 2018\ESK\esk20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ESK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ESK\esk20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=197 > counter.bat

:D197
echo 27%% - downloading file: 2018\EYR\eyr20180118dmin.min
set errmsg="Unable to download 2018\EYR\eyr20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=EYR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\EYR\eyr20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=198 > counter.bat

:D198
echo 28%% - downloading file: 2018\FCC\fcc20180118dmin.min
set errmsg="Unable to download 2018\FCC\fcc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=FCC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\FCC\fcc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=199 > counter.bat

:D199
echo 29%% - downloading file: 2018\FRD\frd20180118dmin.min
set errmsg="Unable to download 2018\FRD\frd20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=FRD&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\FRD\frd20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=200 > counter.bat

:D200
echo 29%% - downloading file: 2018\FRN\frn20180118dmin.min
set errmsg="Unable to download 2018\FRN\frn20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=FRN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\FRN\frn20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=201 > counter.bat

:D201
echo 30%% - downloading file: 2018\FUR\fur20180118dmin.min
set errmsg="Unable to download 2018\FUR\fur20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=FUR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\FUR\fur20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=202 > counter.bat

:D202
echo 31%% - downloading file: 2018\GAN\gan20180118dmin.min
set errmsg="Unable to download 2018\GAN\gan20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GAN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GAN\gan20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=203 > counter.bat

:D203
echo 31%% - downloading file: 2018\GCK\gck20180118dmin.min
set errmsg="Unable to download 2018\GCK\gck20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GCK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GCK\gck20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=204 > counter.bat

:D204
echo 32%% - downloading file: 2018\GDH\gdh20180118dmin.min
set errmsg="Unable to download 2018\GDH\gdh20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GDH&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GDH\gdh20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=205 > counter.bat

:D205
echo 33%% - downloading file: 2018\GLN\gln20180118dmin.min
set errmsg="Unable to download 2018\GLN\gln20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GLN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GLN\gln20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=206 > counter.bat

:D206
echo 33%% - downloading file: 2018\GNA\gna20180118dmin.min
set errmsg="Unable to download 2018\GNA\gna20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GNA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GNA\gna20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=207 > counter.bat

:D207
echo 34%% - downloading file: 2018\GNG\gng20180118dmin.min
set errmsg="Unable to download 2018\GNG\gng20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GNG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GNG\gng20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=208 > counter.bat

:D208
echo 35%% - downloading file: 2018\GUA\gua20180118dmin.min
set errmsg="Unable to download 2018\GUA\gua20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GUA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GUA\gua20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=209 > counter.bat

:D209
echo 35%% - downloading file: 2018\GUI\gui20180118dmin.min
set errmsg="Unable to download 2018\GUI\gui20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GUI&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GUI\gui20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=210 > counter.bat

:D210
echo 36%% - downloading file: 2018\GZH\gzh20180118dmin.min
set errmsg="Unable to download 2018\GZH\gzh20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=GZH&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\GZH\gzh20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=211 > counter.bat

:D211
echo 37%% - downloading file: 2018\HAD\had20180118dmin.min
set errmsg="Unable to download 2018\HAD\had20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HAD&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HAD\had20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=212 > counter.bat

:D212
echo 37%% - downloading file: 2018\HBK\hbk20180118dmin.min
set errmsg="Unable to download 2018\HBK\hbk20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HBK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HBK\hbk20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=213 > counter.bat

:D213
echo 38%% - downloading file: 2018\HER\her20180118dmin.min
set errmsg="Unable to download 2018\HER\her20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HER&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HER\her20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=214 > counter.bat

:D214
echo 38%% - downloading file: 2018\HLP\hlp20180118dmin.min
set errmsg="Unable to download 2018\HLP\hlp20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HLP&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HLP\hlp20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=215 > counter.bat

:D215
echo 39%% - downloading file: 2018\HON\hon20180118dmin.min
set errmsg="Unable to download 2018\HON\hon20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HON&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HON\hon20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=216 > counter.bat

:D216
echo 40%% - downloading file: 2018\HRB\hrb20180118dmin.min
set errmsg="Unable to download 2018\HRB\hrb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HRB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HRB\hrb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=217 > counter.bat

:D217
echo 40%% - downloading file: 2018\HRN\hrn20180118dmin.min
set errmsg="Unable to download 2018\HRN\hrn20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HRN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HRN\hrn20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=218 > counter.bat

:D218
echo 41%% - downloading file: 2018\HUA\hua20180118dmin.min
set errmsg="Unable to download 2018\HUA\hua20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HUA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HUA\hua20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=219 > counter.bat

:D219
echo 42%% - downloading file: 2018\HYB\hyb20180118dmin.min
set errmsg="Unable to download 2018\HYB\hyb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=HYB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\HYB\hyb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=220 > counter.bat

:D220
echo 42%% - downloading file: 2018\IPM\ipm20180118dmin.min
set errmsg="Unable to download 2018\IPM\ipm20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=IPM&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\IPM\ipm20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=221 > counter.bat

:D221
echo 43%% - downloading file: 2018\IQA\iqa20180118dmin.min
set errmsg="Unable to download 2018\IQA\iqa20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=IQA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\IQA\iqa20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=222 > counter.bat

:D222
echo 44%% - downloading file: 2018\IRT\irt20180118dmin.min
set errmsg="Unable to download 2018\IRT\irt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=IRT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\IRT\irt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=223 > counter.bat

:D223
echo 44%% - downloading file: 2018\ISK\isk20180118dmin.min
set errmsg="Unable to download 2018\ISK\isk20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ISK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ISK\isk20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=224 > counter.bat

:D224
echo 45%% - downloading file: 2018\IZN\izn20180118dmin.min
set errmsg="Unable to download 2018\IZN\izn20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=IZN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\IZN\izn20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=225 > counter.bat

:D225
echo 46%% - downloading file: 2018\JAI\jai20180118dmin.min
set errmsg="Unable to download 2018\JAI\jai20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=JAI&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\JAI\jai20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=226 > counter.bat

:D226
echo 46%% - downloading file: 2018\JCO\jco20180118dmin.min
set errmsg="Unable to download 2018\JCO\jco20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=JCO&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\JCO\jco20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=227 > counter.bat

:D227
echo 47%% - downloading file: 2018\KAK\kak20180118dmin.min
set errmsg="Unable to download 2018\KAK\kak20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KAK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KAK\kak20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=228 > counter.bat

:D228
echo 48%% - downloading file: 2018\KDU\kdu20180118dmin.min
set errmsg="Unable to download 2018\KDU\kdu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KDU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KDU\kdu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=229 > counter.bat

:D229
echo 48%% - downloading file: 2018\KEP\kep20180118dmin.min
set errmsg="Unable to download 2018\KEP\kep20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KEP&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KEP\kep20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=230 > counter.bat

:D230
echo 49%% - downloading file: 2018\KHB\khb20180118dmin.min
set errmsg="Unable to download 2018\KHB\khb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KHB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KHB\khb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=231 > counter.bat

:D231
echo 50%% - downloading file: 2018\KIR\kir20180118dmin.min
set errmsg="Unable to download 2018\KIR\kir20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KIR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KIR\kir20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=232 > counter.bat

:D232
echo 50%% - downloading file: 2018\KIV\kiv20180118dmin.min
set errmsg="Unable to download 2018\KIV\kiv20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KIV&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KIV\kiv20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=233 > counter.bat

:D233
echo 51%% - downloading file: 2018\KMH\kmh20180118dmin.min
set errmsg="Unable to download 2018\KMH\kmh20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KMH&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KMH\kmh20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=234 > counter.bat

:D234
echo 51%% - downloading file: 2018\KNY\kny20180118dmin.min
set errmsg="Unable to download 2018\KNY\kny20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KNY&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KNY\kny20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=235 > counter.bat

:D235
echo 52%% - downloading file: 2018\KOU\kou20180118dmin.min
set errmsg="Unable to download 2018\KOU\kou20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=KOU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\KOU\kou20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=236 > counter.bat

:D236
echo 53%% - downloading file: 2018\LER\ler20180118dmin.min
set errmsg="Unable to download 2018\LER\ler20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LER&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LER\ler20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=237 > counter.bat

:D237
echo 53%% - downloading file: 2018\LNP\lnp20180118dmin.min
set errmsg="Unable to download 2018\LNP\lnp20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LNP&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LNP\lnp20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=238 > counter.bat

:D238
echo 54%% - downloading file: 2018\LON\lon20180118dmin.min
set errmsg="Unable to download 2018\LON\lon20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LON&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LON\lon20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=239 > counter.bat

:D239
echo 55%% - downloading file: 2018\LOV\lov20180118dmin.min
set errmsg="Unable to download 2018\LOV\lov20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LOV&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LOV\lov20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=240 > counter.bat

:D240
echo 55%% - downloading file: 2018\LRM\lrm20180118dmin.min
set errmsg="Unable to download 2018\LRM\lrm20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LRM&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LRM\lrm20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=241 > counter.bat

:D241
echo 56%% - downloading file: 2018\LVV\lvv20180118dmin.min
set errmsg="Unable to download 2018\LVV\lvv20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LVV&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LVV\lvv20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=242 > counter.bat

:D242
echo 57%% - downloading file: 2018\LYC\lyc20180118dmin.min
set errmsg="Unable to download 2018\LYC\lyc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LYC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LYC\lyc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=243 > counter.bat

:D243
echo 57%% - downloading file: 2018\LZH\lzh20180118dmin.min
set errmsg="Unable to download 2018\LZH\lzh20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=LZH&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\LZH\lzh20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=244 > counter.bat

:D244
echo 58%% - downloading file: 2018\MAB\mab20180118dmin.min
set errmsg="Unable to download 2018\MAB\mab20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MAB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MAB\mab20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=245 > counter.bat

:D245
echo 59%% - downloading file: 2018\MAW\maw20180118dmin.min
set errmsg="Unable to download 2018\MAW\maw20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MAW&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MAW\maw20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=246 > counter.bat

:D246
echo 59%% - downloading file: 2018\MBC\mbc20180118dmin.min
set errmsg="Unable to download 2018\MBC\mbc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MBC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MBC\mbc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=247 > counter.bat

:D247
echo 60%% - downloading file: 2018\MBO\mbo20180118dmin.min
set errmsg="Unable to download 2018\MBO\mbo20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MBO&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MBO\mbo20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=248 > counter.bat

:D248
echo 61%% - downloading file: 2018\MCQ\mcq20180118dmin.min
set errmsg="Unable to download 2018\MCQ\mcq20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MCQ&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MCQ\mcq20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=249 > counter.bat

:D249
echo 61%% - downloading file: 2018\MEA\mea20180118dmin.min
set errmsg="Unable to download 2018\MEA\mea20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MEA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MEA\mea20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=250 > counter.bat

:D250
echo 62%% - downloading file: 2018\MGD\mgd20180118dmin.min
set errmsg="Unable to download 2018\MGD\mgd20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MGD&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MGD\mgd20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=251 > counter.bat

:D251
echo 62%% - downloading file: 2018\MID\mid20180118dmin.min
set errmsg="Unable to download 2018\MID\mid20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MID&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MID\mid20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=252 > counter.bat

:D252
echo 63%% - downloading file: 2018\MLT\mlt20180118dmin.min
set errmsg="Unable to download 2018\MLT\mlt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MLT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MLT\mlt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=253 > counter.bat

:D253
echo 64%% - downloading file: 2018\MMB\mmb20180118dmin.min
set errmsg="Unable to download 2018\MMB\mmb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MMB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MMB\mmb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=254 > counter.bat

:D254
echo 64%% - downloading file: 2018\MZL\mzl20180118dmin.min
set errmsg="Unable to download 2018\MZL\mzl20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=MZL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\MZL\mzl20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=255 > counter.bat

:D255
echo 65%% - downloading file: 2018\NAQ\naq20180118dmin.min
set errmsg="Unable to download 2018\NAQ\naq20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NAQ&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NAQ\naq20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=256 > counter.bat

:D256
echo 66%% - downloading file: 2018\NCK\nck20180118dmin.min
set errmsg="Unable to download 2018\NCK\nck20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NCK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NCK\nck20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=257 > counter.bat

:D257
echo 66%% - downloading file: 2018\NEW\new20180118dmin.min
set errmsg="Unable to download 2018\NEW\new20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NEW&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NEW\new20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=258 > counter.bat

:D258
echo 67%% - downloading file: 2018\NGK\ngk20180118dmin.min
set errmsg="Unable to download 2018\NGK\ngk20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NGK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NGK\ngk20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=259 > counter.bat

:D259
echo 68%% - downloading file: 2018\NUR\nur20180118dmin.min
set errmsg="Unable to download 2018\NUR\nur20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NUR&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NUR\nur20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=260 > counter.bat

:D260
echo 68%% - downloading file: 2018\NVS\nvs20180118dmin.min
set errmsg="Unable to download 2018\NVS\nvs20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=NVS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\NVS\nvs20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=261 > counter.bat

:D261
echo 69%% - downloading file: 2018\ORC\orc20180118dmin.min
set errmsg="Unable to download 2018\ORC\orc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=ORC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\ORC\orc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=262 > counter.bat

:D262
echo 70%% - downloading file: 2018\OTT\ott20180118dmin.min
set errmsg="Unable to download 2018\OTT\ott20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=OTT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\OTT\ott20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=263 > counter.bat

:D263
echo 70%% - downloading file: 2018\PAF\paf20180118dmin.min
set errmsg="Unable to download 2018\PAF\paf20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PAF&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PAF\paf20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=264 > counter.bat

:D264
echo 71%% - downloading file: 2018\PAG\pag20180118dmin.min
set errmsg="Unable to download 2018\PAG\pag20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PAG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PAG\pag20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=265 > counter.bat

:D265
echo 72%% - downloading file: 2018\PBQ\pbq20180118dmin.min
set errmsg="Unable to download 2018\PBQ\pbq20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PBQ&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PBQ\pbq20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=266 > counter.bat

:D266
echo 72%% - downloading file: 2018\PEG\peg20180118dmin.min
set errmsg="Unable to download 2018\PEG\peg20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PEG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PEG\peg20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=267 > counter.bat

:D267
echo 73%% - downloading file: 2018\PET\pet20180118dmin.min
set errmsg="Unable to download 2018\PET\pet20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PET&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PET\pet20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=268 > counter.bat

:D268
echo 74%% - downloading file: 2018\PHU\phu20180118dmin.min
set errmsg="Unable to download 2018\PHU\phu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PHU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PHU\phu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=269 > counter.bat

:D269
echo 74%% - downloading file: 2018\PIL\pil20180118dmin.min
set errmsg="Unable to download 2018\PIL\pil20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PIL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PIL\pil20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=270 > counter.bat

:D270
echo 75%% - downloading file: 2018\PPT\ppt20180118dmin.min
set errmsg="Unable to download 2018\PPT\ppt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PPT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PPT\ppt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=271 > counter.bat

:D271
echo 75%% - downloading file: 2018\PST\pst20180118dmin.min
set errmsg="Unable to download 2018\PST\pst20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=PST&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\PST\pst20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=272 > counter.bat

:D272
echo 76%% - downloading file: 2018\QSB\qsb20180118dmin.min
set errmsg="Unable to download 2018\QSB\qsb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=QSB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\QSB\qsb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=273 > counter.bat

:D273
echo 77%% - downloading file: 2018\RES\res20180118dmin.min
set errmsg="Unable to download 2018\RES\res20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=RES&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\RES\res20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=274 > counter.bat

:D274
echo 77%% - downloading file: 2018\REU\reu20180118dmin.min
set errmsg="Unable to download 2018\REU\reu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=REU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\REU\reu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=275 > counter.bat

:D275
echo 78%% - downloading file: 2018\SBA\sba20180118dmin.min
set errmsg="Unable to download 2018\SBA\sba20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SBA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SBA\sba20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=276 > counter.bat

:D276
echo 79%% - downloading file: 2018\SBL\sbl20180118dmin.min
set errmsg="Unable to download 2018\SBL\sbl20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SBL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SBL\sbl20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=277 > counter.bat

:D277
echo 79%% - downloading file: 2018\SFS\sfs20180118dmin.min
set errmsg="Unable to download 2018\SFS\sfs20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SFS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SFS\sfs20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=278 > counter.bat

:D278
echo 80%% - downloading file: 2018\SHE\she20180118dmin.min
set errmsg="Unable to download 2018\SHE\she20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SHE&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SHE\she20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=279 > counter.bat

:D279
echo 81%% - downloading file: 2018\SHU\shu20180118dmin.min
set errmsg="Unable to download 2018\SHU\shu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SHU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SHU\shu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=280 > counter.bat

:D280
echo 81%% - downloading file: 2018\SIT\sit20180118dmin.min
set errmsg="Unable to download 2018\SIT\sit20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SIT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SIT\sit20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=281 > counter.bat

:D281
echo 82%% - downloading file: 2018\SJG\sjg20180118dmin.min
set errmsg="Unable to download 2018\SJG\sjg20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SJG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SJG\sjg20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=282 > counter.bat

:D282
echo 83%% - downloading file: 2018\SOD\sod20180118dmin.min
set errmsg="Unable to download 2018\SOD\sod20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SOD&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SOD\sod20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=283 > counter.bat

:D283
echo 83%% - downloading file: 2018\SPG\spg20180118dmin.min
set errmsg="Unable to download 2018\SPG\spg20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SPG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SPG\spg20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=284 > counter.bat

:D284
echo 84%% - downloading file: 2018\SPT\spt20180118dmin.min
set errmsg="Unable to download 2018\SPT\spt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SPT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SPT\spt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=285 > counter.bat

:D285
echo 85%% - downloading file: 2018\STJ\stj20180118dmin.min
set errmsg="Unable to download 2018\STJ\stj20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=STJ&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\STJ\stj20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=286 > counter.bat

:D286
echo 85%% - downloading file: 2018\STT\stt20180118dmin.min
set errmsg="Unable to download 2018\STT\stt20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=STT&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\STT\stt20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=287 > counter.bat

:D287
echo 86%% - downloading file: 2018\SUA\sua20180118dmin.min
set errmsg="Unable to download 2018\SUA\sua20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=SUA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\SUA\sua20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=288 > counter.bat

:D288
echo 87%% - downloading file: 2018\TAM\tam20180118dmin.min
set errmsg="Unable to download 2018\TAM\tam20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TAM&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TAM\tam20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=289 > counter.bat

:D289
echo 87%% - downloading file: 2018\TAN\tan20180118dmin.min
set errmsg="Unable to download 2018\TAN\tan20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TAN&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TAN\tan20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=290 > counter.bat

:D290
echo 88%% - downloading file: 2018\TDC\tdc20180118dmin.min
set errmsg="Unable to download 2018\TDC\tdc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TDC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TDC\tdc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=291 > counter.bat

:D291
echo 88%% - downloading file: 2018\THL\thl20180118dmin.min
set errmsg="Unable to download 2018\THL\thl20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=THL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\THL\thl20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=292 > counter.bat

:D292
echo 89%% - downloading file: 2018\THY\thy20180118dmin.min
set errmsg="Unable to download 2018\THY\thy20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=THY&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\THY\thy20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=293 > counter.bat

:D293
echo 90%% - downloading file: 2018\TIK\tik20180118dmin.min
set errmsg="Unable to download 2018\TIK\tik20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TIK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TIK\tik20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=294 > counter.bat

:D294
echo 90%% - downloading file: 2018\TSU\tsu20180118dmin.min
set errmsg="Unable to download 2018\TSU\tsu20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TSU&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TSU\tsu20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=295 > counter.bat

:D295
echo 91%% - downloading file: 2018\TTB\ttb20180118dmin.min
set errmsg="Unable to download 2018\TTB\ttb20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TTB&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TTB\ttb20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=296 > counter.bat

:D296
echo 92%% - downloading file: 2018\TUC\tuc20180118dmin.min
set errmsg="Unable to download 2018\TUC\tuc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=TUC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\TUC\tuc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=297 > counter.bat

:D297
echo 92%% - downloading file: 2018\UPS\ups20180118dmin.min
set errmsg="Unable to download 2018\UPS\ups20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=UPS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\UPS\ups20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=298 > counter.bat

:D298
echo 93%% - downloading file: 2018\VAL\val20180118dmin.min
set errmsg="Unable to download 2018\VAL\val20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=VAL&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\VAL\val20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=299 > counter.bat

:D299
echo 94%% - downloading file: 2018\VIC\vic20180118dmin.min
set errmsg="Unable to download 2018\VIC\vic20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=VIC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\VIC\vic20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=300 > counter.bat

:D300
echo 94%% - downloading file: 2018\VNA\vna20180118dmin.min
set errmsg="Unable to download 2018\VNA\vna20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=VNA&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\VNA\vna20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=301 > counter.bat

:D301
echo 95%% - downloading file: 2018\VOS\vos20180118dmin.min
set errmsg="Unable to download 2018\VOS\vos20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=VOS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\VOS\vos20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=302 > counter.bat

:D302
echo 96%% - downloading file: 2018\VSS\vss20180118dmin.min
set errmsg="Unable to download 2018\VSS\vss20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=VSS&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\VSS\vss20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=303 > counter.bat

:D303
echo 96%% - downloading file: 2018\WIC\wic20180118dmin.min
set errmsg="Unable to download 2018\WIC\wic20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=WIC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\WIC\wic20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=304 > counter.bat

:D304
echo 97%% - downloading file: 2018\WMQ\wmq20180118dmin.min
set errmsg="Unable to download 2018\WMQ\wmq20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=WMQ&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\WMQ\wmq20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=305 > counter.bat

:D305
echo 98%% - downloading file: 2018\WNG\wng20180118dmin.min
set errmsg="Unable to download 2018\WNG\wng20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=WNG&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\WNG\wng20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=306 > counter.bat

:D306
echo 98%% - downloading file: 2018\YAK\yak20180118dmin.min
set errmsg="Unable to download 2018\YAK\yak20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=YAK&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\YAK\yak20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=307 > counter.bat

:D307
echo 99%% - downloading file: 2018\YKC\ykc20180118dmin.min
set errmsg="Unable to download 2018\YKC\ykc20180118dmin.min"
call getfile "https://imag-data.bgs.ac.uk/GIN_V1/GINServices?Request=GetData&format=IAGA2002&testObsys=0&observatoryIagaCode=YKC&samplesPerDay=1440&orientation=XYZF&publicationState=definitive&recordTermination=Windows&dataStartDate=2018-01-18&dataDuration=1" "2018\YKC\ykc20180118dmin.min" 4
if %gmstatus%==1 goto errhand
echo set gmcount=308 > counter.bat

:D308
rem normal completion point
echo 100%% - data download complete
del counter.bat
goto endscript

:errhand
echo Error: %errmsg%
goto endscript

:endscript
rem tidy up
set gmstatus=
set gmcount=
set errmsg=
