% function [outputArg1,outputArg2] = BBBchazhi(inputArg1,inputArg2)
% %BBBCHAZHI �˴���ʾ�йش˺�����ժҪ
% %   �˴���ʾ��ϸ˵��
% outputArg1 = inputArg1;
% outputArg2 = inputArg2;
% end

function [X,Y,Z] = Bcz(AAA)

Aid=find(AAA==0);
AAA(Aid)=0.1;
N=length(AAA);

for i=1:N
Fi(i,1)=(sind(AAA(i,2)/4+45))*sind(AAA(i,1)-90);
Fi(i,2)=(cosd(AAA(i,2)/4+45)*cosd(90-AAA(i,1)))/4;
Fi(i,3)=(Fi(i,1)*AAA(i,3)-Fi(i,2)*AAA(i,4))/AAA(i,5);
Dt(i,1)=(Fi(i,3)*AAA(i,4)-Fi(i,2)*AAA(i,5))/(Fi(i,1)*Fi(i,1)+Fi(i,2)*Fi(i,2)+Fi(i,3)*Fi(i,3));
Dt(i,2)=(Fi(i,1)*AAA(i,5)+Fi(i,3)*AAA(i,3))/(Fi(i,1)*Fi(i,1)+Fi(i,2)*Fi(i,2)+Fi(i,3)*Fi(i,3));
Dt(i,3)=(-Fi(i,2)*AAA(i,3)-Fi(i,1)*AAA(i,4))/(Fi(i,1)*Fi(i,1)+Fi(i,2)*Fi(i,2)+Fi(i,3)*Fi(i,3));
end

for i=1:N
    
    SJ2(i,1)=360-AAA(i,1);
    jjd=180+AAA(i,2);
    if jjd<=360
        SJ2(i,2)=jjd;
    else
        SJ2(i,2)=jjd-360;
    end
    SJ2(i,3)=Fi(i,3);
    SJ2(i,4)=Dt(i,1);
    SJ2(i,5)=Dt(i,2);
    SJ2(i,6)=Dt(i,3);
    SJ3(i,1)=AAA(i,1);
    SJ3(i,2)=AAA(i,2);
    SJ3(i,3)=Fi(i,3);
    SJ3(i,4)=Dt(i,1);
    SJ3(i,5)=Dt(i,2);
    SJ3(i,6)=Dt(i,3);
end

SJJ=[SJ3;SJ2];

%������
SJJ12=SJJ;
SJJ12(:,2)=SJJ12(:,2)+360;
SJJ13=SJJ;
SJJ13(:,2)=SJJ13(:,2)+720;
SJJ1=[SJJ;SJJ12;SJJ13];
SJJ2=SJJ1;
SJJ2(:,1)=SJJ2(:,1)+360;
SJJ3=SJJ1;
SJJ3(:,1)=SJJ3(:,1)+720;
SJJend=[SJJ1;SJJ2;SJJ3];

[xq,yq]=meshgrid(181:1:540, 361:1:720);
x=SJJend(:,1);
y=SJJend(:,2);
v1=SJJend(:,3);
Fi3=griddata(x,y,v1,xq,yq,'cubic');
v2=SJJend(:,4);
Dt1=griddata(x,y,v2,xq,yq,'cubic');
v3=SJJend(:,5);
Dt2=griddata(x,y,v3,xq,yq,'cubic');
v4=SJJend(:,6);
Dt3=griddata(x,y,v4,xq,yq,'cubic');

%==============================================
for i=1:180
    for j=1:360
       FF1(i,j)=(sind(j/4+45))*sind(i-90);
       FF2(i,j)=(cosd(j/4+45)*cosd(90-i))/4;
       FF3(i,j)=(Fi3(j,i+180));
       DD1(i,j)=Dt1(j,i+180);
       DD2(i,j)=Dt2(j,i+180);
       DD3(i,j)=Dt3(j,i+180);

    end
end
%=============================================
Fii1=FF1;
Fii2=FF2;
Fii3=FF3;
Dtt1=DD1;
Dtt2=DD2;
Dtt3=DD3;

X=-Fii2.*Dtt3+Fii3.*Dtt2;
Y=Fii3.*Dtt1-Fii1.*Dtt3;
Z=Fii1.*Dtt2-Fii2.*Dtt1;

end








