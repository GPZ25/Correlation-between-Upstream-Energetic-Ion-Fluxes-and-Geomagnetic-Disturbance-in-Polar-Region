clc
clear
clearvars
%==================================
%=abk180202;jco190121;jco190129;abk181208;abk180311;jco180205;jco181105===
dH=[101.62;227.34;289.61;474.97;538.43;740.26;1118.04];
%======================================
%1
ah(1,1)=3.2138*(10^15);
bh(1,1)=-7.7074;
ahe(1,1)=16.4088*(10^0);
bhe(1,1)=-0.0356;
ao(1,1)=3.0480*(10^0);
bo(1,1)=-0.0175;
%2
ah(2,1)=7.6122*(10^14);
bh(2,1)=-7.1490;
ahe(2,1)=19.6596*(10^0);
bhe(2,1)=-0.0333;
ao(2,1)=1.2646*(10^0);
bo(2,1)=-0.0114;
%3
ah(3,1)=1.3047*(10^15);
bh(3,1)=-7.3955;
ahe(3,1)=15.5836*(10^0);
bhe(3,1)=-0.0374;
ao(3,1)=3.9524*(10^0);
bo(3,1)=-0.0179;
%4
ah(4,1)=5.4942*(10^11);
bh(4,1)=-5.3834;
ahe(4,1)=33.3116*(10^0);
bhe(4,1)=-0.0190;
ao(4,1)=1.2807*(10^0);
bo(4,1)=-0.0063;
%5
ah(5,1)=3.6880*(10^13);
bh(5,1)=-6.4014;
ahe(5,1)=21.2102*(10^0);
bhe(5,1)=-0.0257;
ao(5,1)=2.3816*(10^0);
bo(5,1)=-0.0129;
%6
ah(6,1)=8.1836*(10^11);
bh(6,1)=-5.1185;
ahe(6,1)=28.8009*(10^0);
bhe(6,1)=-0.0185;
ao(6,1)=1.9049*(10^0);
bo(6,1)=-0.0099;
%7
ah(7,1)=8.7977*(10^10);
bh(7,1)=-4.8035;
ahe(7,1)=29.8964*(10^0);
bhe(7,1)=-0.0152;
ao(7,1)=18.1999*(10^0);
bo(7,1)=-0.0182;
%==============================================
Xeg=(100:1:700);
for i=1:7
H(i,:)=ah(i,1).*Xeg.^bh(i,1);
He(i,:)=ahe(i,1)*exp(bhe(i,1).*Xeg);
O(i,:)=ao(i,1)*exp(bo(i,1).*Xeg);
end
Rh=100*H./(H+He+O);
Rhe=100*He./(H+He+O);
Ro=100*O./(H+He+O);
%====================================================
%TP*4
TP=tiledlayout(3,2);
TP.TileSpacing = 'compact';
TP.Padding = 'compact';
%=============================
%TP-1/4
nexttile(1)
plot(Xeg,H(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,H(5,:),'Color','g','LineWidth',2)
plot(Xeg,H(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,H(1,:),'Color','k','LineWidth',1)
hold off
set(gca,'yscale','log');
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
% set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
% axis([9 800 0 1000000000]);
ylabel({'Proton';'Average Flux';'[1/(cm^{2}-sr-s-keV)]'});
leg2=legend({'740.26 nT','538.43 nT','227.34 nT','101.62 nT'}, 'Location', 'SouthWest');
leg2.ItemTokenSize = [10,1];
text(600,5,'(a)','Color','k')
%========================================================
%TP-2/4
nexttile(3)
plot(Xeg,He(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,He(5,:),'Color','g','LineWidth',2)
plot(Xeg,He(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,He(1,:),'Color','k','LineWidth',1)
hold off
set(gca,'yscale','log');
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
% set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
% axis([9 800 0 1000000000]);
ylabel({'Alpha particle';'Average Flux';'[1/(cm^{2}-sr-s-keV)]'});
leg2=legend({'740.26 nT','538.43 nT','227.34 nT','101.62 nT'}, 'Location', 'SouthWest');
leg2.ItemTokenSize = [10,1];
text(600,0.25,'(c)','Color','k')
%========================================================
%TP-3/4
nexttile(5)
plot(Xeg,O(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,O(5,:),'Color','g','LineWidth',2)
plot(Xeg,O(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,O(1,:),'Color','k','LineWidth',1)
hold off
set(gca,'yscale','log');
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
% set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
% axis([9 800 0 1000000000]);
ylabel({'Oxygen ion';'Average Flux';'[1/(cm^{2}-sr-s-keV)]'});
leg2=legend({'740.26 nT','538.43 nT','227.34 nT','101.62 nT'}, 'Location', 'SouthWest');
leg2.ItemTokenSize = [10,1];
text(600,0.22,'(e)','Color','k')
xlabel('[keV]')

%========================================================
%TP-4/4
nexttile(2)
plot(Xeg,Rh(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,Rh(5,:),'Color','g','LineWidth',2)
plot(Xeg,Rh(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,Rh(1,:),'Color','k','LineWidth',1)
hold off
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
set(gca,'ytick',[0 50 100 ]);
axis([100 700 0 100]);
% set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
% axis([9 800 0 1000000000]);
ylabel({'Flux Ratio';'[%]'});
% leg2=legend({'740.26nT','538.43nT','227.34nT','101.62nT'}, 'Location', 'SouthEast');
% leg2.ItemTokenSize = [10,1];
text(600,87,'(b)','Color','k')
%========================================================
%TP-5/4
nexttile(4)
plot(Xeg,Rhe(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,Rhe(5,:),'Color','g','LineWidth',2)
plot(Xeg,Rhe(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,Rhe(1,:),'Color','k','LineWidth',1)
xline(124,'--k','LineWidth',1)
xline(141,'--b','LineWidth',1.5)
xline(161,'--g','LineWidth',2)
xline(240,'--r','LineWidth',2.5)

% quiver(300, 0.0001 ,0 , 0.2,'k','linewidth',3, 'ShowArrowHead', 'on')

hold off
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
set(gca,'ytick',[0 50 100 ]);
axis([100 700 0 100]);
ylabel({'Flux Ratio';'[%]'});
% leg2=legend({'740.26nT','538.43nT','227.34nT','101.62nT'}, 'Location', 'SouthEast');
% leg2.ItemTokenSize = [10,1];
text(600,87,'(d)','Color','k')
%========================================================
%TP-6/4
nexttile(6)
plot(Xeg,Ro(6,:),'Color','r','LineWidth',2.5)
hold on
plot(Xeg,Ro(5,:),'Color','g','LineWidth',2)
plot(Xeg,Ro(2,:),'Color','b','LineWidth',1.5)
plot(Xeg,Ro(1,:),'Color','k','LineWidth',1)
hold off
set(gca,'xscale','log');
set(gca,'xtick',[100 200 400 700 ]);
% xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
set(gca,'ytick',[0 50 100 ]);
axis([100 700 0 100]);
% set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
% axis([9 800 0 1000000000]);
ylabel({'Flux Ratio';'[%]'});
% leg2=legend({'740.26nT','538.43nT','227.34nT','101.62nT'}, 'Location', 'SouthEast');
% leg2.ItemTokenSize = [10,1];
text(600,87,'(f)','Color','k')
%========================================================
xlabel('[keV]')









