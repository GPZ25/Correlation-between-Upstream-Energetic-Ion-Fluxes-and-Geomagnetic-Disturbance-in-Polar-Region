clc
clear
clearvars
%==================================

%=======================================
%proton ex
data1=cdfread("mms4_epd-eis_srvy_l2_extof_20181105_v4.5.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_proton_P4_flux_t0");
N1=length(data1);
X1=[54.2381;79.5544;115.0262;176.9948;288.6663;470.0688;766.5541];

avgt=fix(N1/24*0.5);
e1=fix(N1/24*22);
f1=fix(N1/24*22.5);
for j=1:7
    for k=e1:f1
    lsz(k-e1+1,1)=double(data1{k,1}(j));
    end
    H(j,1)=sum(lsz);
end
H=H/avgt;
%============================================================

%===========================================================
%helium
data2=cdfread("mms4_epd-eis_srvy_l2_extof_20181105_v4.5.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_helium_P4_flux_t0");
N2=length(data2);
X2=[78.8011;138.8380;227.0866;369.4784;679.5564];
e2=fix(N2/24*22);
f2=fix(N2/24*22.5);
for j=1:5
    for k=e2:f2
    lsz(k-e2+1,1)=double(data2{k,1}(j));
    end
    He(j,1)=sum(lsz);
end
He=He/avgt;
% He(3,1)=0.000001;
%========================================================================
%oxygen
data3=cdfread("mms4_epd-eis_srvy_l2_extof_20181105_v4.5.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_oxygen_P4_flux_t0");
N3=length(data3);
X3=[145.1794;190.2873;248.5796;324.4159;423.4234;688.9829];
e3=fix(N3/24*22);
f3=fix(N3/24*22.5);
for j=1:6
    for k=e3:f3
    lsz(k-e3+1,1)=double(data3{k,1}(j));
    end
    O(j,1)=sum(lsz);
end
O=O/avgt;

%==============================================================
X1h=(10:1:800);
%=================================================================================
%TP*4
TP=tiledlayout(2,1);
TP.TileSpacing = 'compact';
TP.Padding = 'compact';
%=============================
%TP-1/4
nexttile
plot(X1h,(2.1883e+15).*X1h.^(-5.0980).*X1h/avgt,'b-','LineWidth',1)

hold on
plot(X1h,(1.8819e+05).*exp(-0.0150.*X1h).*X1h/avgt,'k-','LineWidth',1)
plot(X1h,(1.1043e+04).*exp(-0.0069.*X1h).*X1h/avgt,'r-','LineWidth',1)

plot(X1,H,'X','Color','b','MarkerSize',10)
plot(X2,He,'.','Color','k','MarkerSize',15)
plot(X3,O,'*','Color','r','MarkerSize',10)

% plot([470.0688 470.0688], [0.01 100000000000],'k--')
% plot([766.5541 766.5541], [0.01 100000000000],'k--')
plot([100 100], [0.01 1000000000],'k--')
plot([200 200], [0.01 1000000000],'k--')


hold off
set(gca,'yscale','log');
set(gca,'xscale','log');
% set(gca,'xtick',[ 10 50 100 200 300 500 800]);

xticks(0:100:800)
xticklabels([])
set(gca,'xminortick','on');
set(gca,'yminortick','on');
set(gca,'ytick',[1 100 10000 1000000 100000000 ]);
axis([9 800 0 1000000000]);
ylabel({'MMS4';'Ion Flux';'[eV/(cm^{2}-sr-s-eV)]'});
leg2=legend({'H^+','He^+','O^+'}, 'Location', 'NorthEast');
leg2.ItemTokenSize = [10,1];
% legend boxoff;
text(10,2,'(a)','Color','k')
% text(480,5000,'Flux=0','Color','k')
% text(720,100,'Flux=0','Color','k')

%=============================

%=============================
%=============================
%TP-4/4
nexttile
plot(X1h,100.*((2.1883e+15).*X1h.^(-5.0980))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'b-','LineWidth',1)
hold on
plot(X1h,100.*((1.8819e+05).*exp(-0.0150.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'k-','LineWidth',1)
plot(X1h,100.*((1.1043e+04).*exp(-0.0069.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'r-','LineWidth',1)
plot([200 200], [0 100],'k--')
plot([100 100], [0 100],'k--')


hold off
set(gca,'xscale','log');
xticks(0:100:800)
xticklabels([])

set(gca,'xminortick','on');
set(gca,'yminortick','on');

% set(gca,'xtick',[ 10 50 100 200 300 500 800]);

set(gca,'ytick',[0 25  50  75 100]);
axis([9 800 -1 101]);
ylabel({'MMS4';'Flux Ratio';'[%]'});
leg2=legend({'H^+','He^+','O^+'}, 'Location', 'NorthEast');
leg2.ItemTokenSize = [10,1];
text(10,10,'(b)','Color','k')
text(108,85,'100keV','Color','k')
text(208,85,'200keV','Color','k')

%=============================












%====================================================================
xlabel(TP,'[keV]')























