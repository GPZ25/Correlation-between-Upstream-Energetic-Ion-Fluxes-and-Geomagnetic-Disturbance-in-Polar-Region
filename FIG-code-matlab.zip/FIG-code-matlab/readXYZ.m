% function [outputArg1,outputArg2] = readXYZ(inputArg1,inputArg2)
% %READXYZ �˴���ʾ�йش˺�����ժҪ
% %   �˴���ʾ��ϸ˵��
% outputArg1 = inputArg1;
% outputArg2 = inputArg2;
% end

function [XYZ,N] = readXYZ(ST,N,rdr,pjr)
%READXYZ �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

for i=1:N
    %open wj
    STD=upper(ST{i,1});
    path0=strcat('.\','2018c','\',STD,'\',ST{i,1},rdr,'dmin.min');
    pp0=fopen(path0);
    path1=strcat('.\','2018a','\',STD,'\',ST{i,1},pjr,'dmin.min');
    pp1=fopen(path1);
    
    jiao=ST{i,4};
    XYZ0{i,1}=ST{i,1};
    XYZ0{i,2}=ST{i,2};
    XYZ0{i,3}=ST{i,3};
    
    if pp0~=-1&&pp1~=-1
    rdwj0=textscan(pp0,'%s','delimiter','\t');
    rdsj0=char(rdwj0{1,1});
    pjwj0=textscan(pp1,'%s','delimiter','\t');
    pjsj0=char(pjwj0{1,1});
    fclose(pp0);
    fclose(pp1);
    
    BBB=length(rdsj0);
    
    for j=1:1440
    rd(i,j,1)=str2double(rdsj0(j+BBB-1440,30:40));
    rd(i,j,2)=str2double(rdsj0(j+BBB-1440,41:50));
    rd(i,j,3)=str2double(rdsj0(j+BBB-1440,51:60));
    pj(i,j,1)=str2double(pjsj0(j+BBB-1440,30:40));
    pj(i,j,2)=str2double(pjsj0(j+BBB-1440,41:50));
    pj(i,j,3)=str2double(pjsj0(j+BBB-1440,51:60));
    
    if rd(i,j,1)<=99998&&rd(i,j,2)<=99998&&rd(i,j,3)<=99998&&pj(i,j,1)<=99998&&pj(i,j,2)<=99998&&pj(i,j,3)<=99998
    
    rdz0(i,j,1)=rd(i,j,1)-pj(i,j,1);
    rdz0(i,j,2)=rd(i,j,2)-pj(i,j,2);
    rdz0(i,j,3)=rd(i,j,3)-pj(i,j,3);
    
    rdz(i,j,1)=(rdz0(i,j,1))*cosd(jiao)+(rdz0(i,j,2))*sind(jiao);
    rdz(i,j,2)=(rdz0(i,j,2))*cosd(jiao)-(rdz0(i,j,1))*sind(jiao);
    rdz(i,j,3)=rdz0(i,j,3);
    
    XYZ0{i,4}(j,1)=rdz(i,j,1);
    XYZ0{i,4}(j,2)=rdz(i,j,2);
    XYZ0{i,4}(j,3)=rdz(i,j,3);
    
    else
     
    XYZ0{i,4}(j,1)=99999;
    XYZ0{i,4}(j,2)=99999;
    XYZ0{i,4}(j,3)=99999; 
        
    end
    
    end
    
    else
        for j=1:1440
       XYZ0{i,4}(j,1)=99999;
       XYZ0{i,4}(j,2)=99999;
       XYZ0{i,4}(j,3)=99999;
        end
    end
   
end

XYZ=XYZ0;

end
