clc
clear
clearvars
%==================================
%Bow shock & 
global A1 B1 C1 D1 E1 A2 B2 C2 D2 E2
A1=0.2164;
B1=-0.0986;
C1=-4.26;
D1=44.916;
E1=-623.77;
A2=0.0278;
B2=0.3531;
C2=-0.586;
D2=17.866;
E2=-233.67;
%======================================
%mag
data0=cdfread("mms4_fgm_srvy_l2_20180202_v5.123.0.cdf","variables","mms4_fgm_b_gse_srvy_l2");
N0=length(data0);
aa0=fix(N0/24*10);
bb0=fix(N0/24*18);
for i=aa0:bb0
    Bx2(i-aa0+1)=data0{i,1}(1);
    By2(i-aa0+1)=data0{i,1}(2);
    Bz2(i-aa0+1)=data0{i,1}(3);
end
XB2=0:bb0-aa0;
YB2=XB2-XB2;
%=================================================
%proton ex
data1=cdfread("mms4_epd-eis_srvy_l2_extof_20180202_v4.3.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_proton_P4_flux_t0");
N1=length(data1);
aa1=fix(N1/24*10);
bb1=fix(N1/24*18);
for i=aa1:bb1
    pro(1,i-aa1+1)=double(data1{i,1}(1));
    pro(2,i-aa1+1)=double(data1{i,1}(2));
    pro(3,i-aa1+1)=double(data1{i,1}(3));
    pro(4,i-aa1+1)=double(data1{i,1}(4));
    pro(5,i-aa1+1)=double(data1{i,1}(5));
    pro(6,i-aa1+1)=double(data1{i,1}(6));
    pro(7,i-aa1+1)=double(data1{i,1}(7));

end
%============================================================
%helium
data2=cdfread("mms4_epd-eis_srvy_l2_extof_20180202_v4.3.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_helium_P4_flux_t0");
N2=length(data2);
aa2=fix(N2/24*10);
bb2=fix(N2/24*18);
for i=aa2:bb2
    hel(1,i-aa2+1)=double(data2{i,1}(1));
    hel(2,i-aa2+1)=double(data2{i,1}(2));
    hel(3,i-aa2+1)=double(data2{i,1}(3));
    hel(4,i-aa2+1)=double(data2{i,1}(4));
    hel(5,i-aa2+1)=double(data2{i,1}(5));
end
%========================================================================
%oxygen
data3=cdfread("mms4_epd-eis_srvy_l2_extof_20180202_v4.3.100.cdf","variables","mms4_epd_eis_srvy_l2_extof_oxygen_P4_flux_t0");
N3=length(data3);
aa3=fix(N3/24*10);
bb3=fix(N3/24*18);
for i=aa3:bb3
    oxy(1,i-aa3+1)=double(data3{i,1}(1));
    oxy(2,i-aa3+1)=double(data3{i,1}(2));
    oxy(3,i-aa3+1)=double(data3{i,1}(3));
    oxy(4,i-aa3+1)=double(data3{i,1}(4));
    oxy(5,i-aa3+1)=double(data3{i,1}(5));
    oxy(6,i-aa3+1)=double(data3{i,1}(6));
end


%=======================================================
%==================================================
%ARTEMIS-P1 & MMS4 & Moon at 20:00 UT
M4x=22.3;
M4y=-8.83;
M4z=6.62;
M4Bx=2.7007;
% M4By=-0.1001;
M4By=-1.0474;

% M4Bz=0.9535;
M4Bz=-0.1261;
%==========================================
X0=-20:0.1:70;
Y0=X0-X0;
Y00=-40:0.1:40;
X00=Y00-Y00;
%bow shock
X=-15:0.1:14.5;
a1=1;
b1=A1*X+C1;
c1=B1*(X.^2)+D1*X+E1;
Yp1=real((-b1+(b1.^2-4*a1*c1).^(1/2))/2);
Yn1=real((-b1-(b1.^2-4*a1*c1).^(1/2))/2);
%
X2=-15:0.1:10.8;
a2=1;
b2=A2*X2+C2;
c2=B2*(X2.^2)+D2*X2+E2;
Yp2=real((-b2+(b2.^2-4*a2*c2).^(1/2))/2);
Yn2=real((-b2-(b2.^2-4*a2*c2).^(1/2))/2);

XA1=14.2:0.1:70;
XM4=13.5:0.1:35;
YM4=(M4By/M4Bx)*(XM4-M4x)+M4y;
XA12=14.4:0.1:70;
XM42=13.9:0.1:70;
ZM4=(M4Bz/M4Bx)*(XM42-M4x)+M4z;
%=======================================================
loclins=fopen('MMS4_2018_33_GSE_XYZ.txt');
locmms=textscan(loclins,'%s','delimiter','\t');
WZmms=char(locmms{1,1});
fclose(loclins);
for i=636:1:1115
    XYMMS(i-635,1)=str2double(WZmms(i,23:31));
    XYMMS(i-635,2)=str2double(WZmms(i,33:43));
end

%==================================================
T=tiledlayout(7,1);
T.TileSpacing = 'compact';
T.Padding = 'compact';
%======================================================
nexttile(1,[2 1])
plot(X,Yp1,'k','LineWidth', 1.5)
hold on
plot(X,Yn1,'k','LineWidth', 1.5)
plot(X2,Yp2,'k','LineWidth', 1.5)
plot(X2,Yn2,'k','LineWidth', 1.5)
% plot(A1x,A1y,'r*','MarkerSize', 7)
plot(21.86,-9.2,'b.','MarkerSize', 8)
plot(22.30,-8.83,'b.','MarkerSize', 8)
plot(22.93,-7.49,'b.','MarkerSize', 8)
plot(XYMMS(:,1),XYMMS(:,2),'b','LineWidth', 1)
% plot(X0,Y0,'k','LineWidth', 0.1)
% plot(X00,Y00,'k','LineWidth', 0.1)
% plot(XA1,YA1,'k--')
plot(XM4,YM4,'k--')
quiver(24, -9.4893 ,5 , 9.4893-11.4284,'k','linewidth',1)
quiver(24, 1.5 ,5 , 0,'k','linewidth',1)
quiver(15, -5 ,3 , 9.4893-10.7,'g','linewidth',1)

%=================================
%Earth
r = 1;
phi = 0:0.01:pi;
y= r*cos(phi); y = [y,y(1)];
x= r*sin(phi); x = [x,x(1)];
patch(x,y,'w');
y2 = r*cos(pi+phi); y2 = [y2,y2(1)];
x2 = r*sin(pi+phi); x2 = [x2,x2(1)];
patch(x2,y2,'k');
%=====================================================
hold off
set (gca,'XDir','reverse')
set (gca,'YDir','reverse')
axis([-5 35 -15 5] )
ylabel('Y_{GSE}(R_{E})','FontSize',8)
text(-2,0,'Earth','FontSize',8 )
% text(56,-28,'Moon')
% text(64,-24,'ARTEMIS-P1','Color','red')
text(24,-6,'MMS4','Color','blue','FontSize',8 )
text(21.5,-9.5,'10:00','Color','blue','FontSize',6 )
text(22.3,-8.5,'12:00','Color','blue','FontSize',6 )
text(22.7,-7.3,'18:00','Color','blue','FontSize',6 )
text(28,-9,'IMF','FontSize',8 )
text(19.5,3,'Bow shock','FontSize',8 )
text(28,0,'To Sun','FontSize',8 )
text(9.5,3,'Magnetopause','FontSize',8 )
text(19,-4,'H^+ He^+ O^+','Color','green','FontSize',8)

text(34,-12,'(a)','FontSize',8 )
set(gca,'xtick',[0 10 20 30 ],'FontSize',8 );
set(gca,'yminortick','on');
set(gca,'xminortick','on');
xlabel('X_{GSE}(R_{E})','FontSize',8 )

%===================================================================
%============================================================
nexttile
plot(Bx2,'b')
hold on
plot(By2,'y')
plot(Bz2,'r')
plot(XB2,YB2,'k--','LineWidth', 0.1)

xxxls=bb0-aa0;
xxy1=[-8;8];
xxx1=[xxxls*1.5/8;xxxls*6.5/8];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
axis([0 bb0-aa0 -8 8]);
xticks(0:fix((bb0-aa0)/4):bb0-aa0)
xticklabels([])
set(gca,'xminortick','on','FontSize',8 );
set(gca,'yminortick','on');
ylabel({'MMS4';'FGM';'[nT]'},'FontSize',8 );
text((bb0-aa0)/75,5.5,'(b)','FontSize',8)
leg=legend({'Bx', 'By','Bz'}, 'Location', 'eastoutside','FontSize',8 );
leg.ItemTokenSize = [10,1];
legend boxoff;
%==========================================================
nexttile
plot(pro(2,:)','r');
hold on
plot(pro(3,:)','y');
plot(pro(4,:)','b');
% plot(pro(5,:)','k');

xxxls=bb1-aa1;
xxy1=[0;200];
xxx1=[xxxls*1.5/8;xxxls*6.5/8];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
axis([0 bb1-aa1 0 200]);
xticks(0:fix((bb1-aa1)/4):bb1-aa1)
xticklabels([])
% set(gca,'yscale','log');
set(gca,'ytick',[50 125 200 ],'FontSize',8 );
set(gca,'xminortick','on');
set(gca,'yminortick','on');
ylabel({'MMS4';'EIS';'Proton Flux';'[1/(cm^{2}-sr-s-keV)]'},'FontSize',8 );
text((bb1-aa1)/75,160,'(c)','Color','k','FontSize',8 )
leg2=legend({'79.6keV','115.0keV','177.0keV'}, 'Location', 'eastoutside','FontSize',8 );
leg2.ItemTokenSize = [10,1];
legend boxoff;
%=============================================================
nexttile
plot(hel(1,:)','r');
hold on
plot(hel(2,:)','y');
plot(hel(3,:)','b');
% plot(hel(4,:)','k');

xxxls=bb2-aa2;
xxy1=[0;50];
xxx1=[xxxls*1.5/8;xxxls*6.5/8];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
% set(gca,'yscale','log');
axis([0 bb2-aa2 0 50]);
xticks(0:fix((bb2-aa2)/4):bb2-aa2)
xticklabels([])
set(gca,'ytick',[10 30 50],'FontSize',8 );

set(gca,'xminortick','on');
set(gca,'yminortick','on');
ylabel({'MMS4';'EIS';'Alpha Flux';'[1/(cm^{2}-sr-s-keV)]'},'FontSize',8 );
% yyaxis right
% yticklabels('1/(cm^{2}-sr-s-keV)');
% yticks(1.5);
% yticklabels({'100'});
text((bb2-aa2)/75,40,'(d)','Color','k','FontSize',8 )
leg2=legend({ '78.8keV','138.8keV','227.1keV'}, 'Location', 'eastoutside','FontSize',8 );
leg2.ItemTokenSize = [10,1];
legend boxoff;
%==================================================
nexttile
plot(oxy(1,:)','r');
hold on
plot(oxy(2,:)','y');
plot(oxy(3,:)','b');
% plot(oxy(4,:)','k');

xxxls=bb3-aa3;
xxy1=[0;50];
xxx1=[xxxls*1.5/8;xxxls*6.5/8];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
% set(gca,'yscale','log');
axis([0 bb3-aa3 0 50]);

xticks(0:fix((bb3-aa3)/4):bb3-aa3)
xticklabels([])
set(gca,'ytick',[10 30 50 ],'FontSize',8 );

set(gca,'xminortick','on');
set(gca,'yminortick','on');
ylabel({'MMS4';'EIS';'Oxygen Flux';'[1/(cm^{2}-sr-s-keV)]'},'FontSize',8 );
% yyaxis right
% yticklabels('1/(cm^{2}-sr-s-keV)');
% yticks(1.5);
% yticklabels({'100'});
text((bb3-aa3)/75,40,'(e)','Color','k','FontSize',8 )
leg2=legend({ '145.2keV','190.3keV','248.6keV'}, 'Location', 'eastoutside','FontSize',8 );
leg2.ItemTokenSize = [10,1];
legend boxoff;
%=================================
%TP-7/6
nexttile
plot(oxy(4,:)','r');
hold on
plot(oxy(5,:)','y');
plot(oxy(6,:)','b');
% plot(oxy(4,:)','k');

xxxls=bb3-aa3;
xxy1=[0;10];
xxx1=[xxxls*1.5/8;xxxls*6.5/8];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
% set(gca,'yscale','log');
axis([0 bb3-aa3 0 10]);
set(gca,'ytick',[2 6 10],'FontSize',8 );

set(gca,'xminortick','on');
set(gca,'yminortick','on');
ylabel({'MMS4';'EIS';'Oxygen Flux';'[1/(cm^{2}-sr-s-keV)]'},'FontSize',8 );
text((bb3-aa3)/75,8,'(f)','Color','k','FontSize',8 )
leg2=legend({ '324.4keV','423.4keV','689.0keV'}, 'Location', 'eastoutside','FontSize',8 );
leg2.ItemTokenSize = [10,1];
legend boxoff;



xticks(0:fix((bb3-aa3)/4):bb3-aa3)
xticklabels({'10:00','12:00','14:00','16:00','18:00'})
xlabel(T,'Time (UT:hhmm) on Feb 02 2018','FontSize',8 )







