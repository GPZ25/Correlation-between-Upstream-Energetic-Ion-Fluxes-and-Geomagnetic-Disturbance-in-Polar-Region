
clc
clear
clearvars
%==================================

%===================================
% rdr='20110909';
% pjr='20110915';
% day='20110909';

rdr='20180202';
pjr='20180118';


[ST,N]=readST(1);
[XYZ,N] =readXYZ(ST,N,rdr,pjr);
% [XYZ,N] =readdXYZ(ST,N,day);

[xx,yy]=meshgrid(-180:1:180,-89:1:90);

sk=90;
% for sk=1:60:1440

for i=1:N
SJ(i,1)=90-XYZ{i,2};
SJ(i,2)=XYZ{i,3};
SJ(i,3)=XYZ{i,4}(sk,1);
SJ(i,4)=XYZ{i,4}(sk,2);
SJ(i,5)=XYZ{i,4}(sk,3);
end

%��ȥ��ȱʧֵ����
id1=SJ(:,3)==99999;
SJ(id1,:)=[];
id2=SJ(:,4)==99999;
SJ(id2,:)=[];
id3=SJ(:,5)==99999;
SJ(id3,:)=[];




%���ݼ�����չ��BMC-I�ṹ
N2=length(SJ);

for i=1:N2
    
    SJ2(i,1)=360-SJ(i,1);
    jjd=180+SJ(i,2);
    if jjd<=360
        SJ2(i,2)=jjd;
    else
        SJ2(i,2)=jjd-360;
    end
    SJ2(i,3)=SJ(i,3);
    SJ2(i,4)=SJ(i,4);
    SJ2(i,5)=SJ(i,5);
    SJ3(i,1)=SJ(i,1);
    SJ3(i,2)=SJ(i,2);
    SJ3(i,3)=SJ(i,3);
    SJ3(i,4)=SJ(i,4);
    SJ3(i,5)=SJ(i,5);
end

SJJ=[SJ3;SJ2];

%������
SJJ12=SJJ;
SJJ12(:,2)=SJJ12(:,2)+360;
SJJ13=SJJ;
SJJ13(:,2)=SJJ13(:,2)+720;
SJJ1=[SJJ;SJJ12;SJJ13];
SJJ2=SJJ1;
SJJ2(:,1)=SJJ2(:,1)+360;
SJJ3=SJJ1;
SJJ3(:,1)=SJJ3(:,1)+720;
SJJend=[SJJ1;SJJ2;SJJ3];

%��ֵ
[xq,yq]=meshgrid(181:1:540, 361:1:720);
x=SJJend(:,2);
y=SJJend(:,1);
v=SJJend(:,3);
vq1=griddata(x,y,v,xq,yq,'v4');
v2=SJJend(:,4);
vq2=griddata(x,y,v2,xq,yq,'v4');
v3=SJJend(:,5);
vq3=griddata(x,y,v3,xq,yq,'v4');

%==================================================
% vq2=flipud(vq2);
% vq1=flipud(vq1);
% vq2=fliplr(vq2);
% vq1=fliplr(vq1);

% JN(41:180,1:360)=0;
% JE(41:180,1:360)=0;
% JN(1:40,1:360)=-(10/(3*pi))*vq2(1:40,1:360);
% JE(1:40,1:360)=(10/(3*pi))*vq1(1:40,1:360);

JN(1:180,1:360)=-(100/(3*pi))*vq2(1:180,1:360);
JE(1:180,1:360)=(100/(3*pi))*vq1(1:180,1:360);


f=spherefunv(JE,JN,0);
% quiver(f)
LW = 'linewidth';

psi = spherefun.poisson( vorticity(f), 0, 359 );
phi = spherefun.poisson( divergence(f), 0, 359 );
% % quiver3( curl( psi ) ), hold on,
% % contour( psi, 'r-', LW , 2 ),
% % title('Divergence-free component of f')
% % view([-36 8]), hold off

% [phi, psi] = helmholtzdecomp( f );
% clf, quiver( f ), hold on
% contour( phi, 'b-', LW , 1.5 )
% hold on,
% contour( psi,  'r-', LW , 1.5 ),hold off;
% title('f (arrows), \phi (blue), and \psi (red)')
% % 
% % hold on, spherefun.plotEarth('k-'), hold off;
% view([90 90])
%  grid on
% axis off
% %==================================================
% contour(psi,20);
% view([90 0])

% % ========================================================
PSI0=sample(psi);
for i=1:180
   PSI(i,:)=PSI0(1*i,:); 
end
PSI=flipud(PSI);

%  PSI=fliplr(PSI);
% PSIII=[PSI,PSI];
% PSI=PSIII(:,121:480);
PSI(:,361)=PSI(:,1);
% PSI=fliplr(PSI);

% for i=1:40
%     for j=1:360
%   
%         PSI(i,j)=PSI0(4*i,2*j) ;
%     end
%     
% end

jing=180-round(sk/4);

% m_proj('robinson','longitudes',[-180 179],'latitudes',[-89 90]);
m_proj('stereographic','lat',50,'long',80,'radius',55);
% 
FGFG=m_contourf(xx,yy,PSI,20);
% % % clabel(FGFG,[MAX,MIN]);
% % % set(gca,'Clim',[-300,300])
% % 
MAX=round(max(max(PSI)));
MIN=round(min(min(PSI)));
MAX=num2str(MAX);
MIN=num2str(MIN);
colormap(jet)
% % % colorbar('horiz')

qhh=colorbar('FontSize',8);
set(get(qhh,'Title'),'string','kA');
% % 
% % % m_coast('patch','g');
% % % m_coast;
% m_grid('linest','--','FontSize',8);
% 
% jing=180-round(sk/4);
% jing2=ones(1,41);
% jing3=jing2*jing;
% wei=50:1:90;
% hold on
% m_plot(jing3,wei,'LineWidth',1.5,'Color','y')
% hold off;

% fff=getframe(gcf);
% [TT,map]=rgb2ind(fff.cdata,256,'nodither');
% if sk==1
%     imwrite(TT,map,'TP111.gif','DelayTime',0,'LoopCount',inf);
% else
%     imwrite(TT,map,'TP111.gif','gif','WriteMode','append','DelayTime',0.5);
% end
% 
% 
% 
% end
axis off
axis equal

%=================================================================
% %��ͼ
% nam001=1:1:361;%���ȷ�������
% theta001=1:1:40;%��γ��������
% [nam01,theta01]=meshgrid(nam001,theta001);
% nam0001=(theta01).*cosd(nam01);
% theta0001=(theta01).*sind(nam01);
% 
% % for SK=1:10:1440
% SK=sk;
% 
% xzj=0.25*SK;
% 
% % for i=1:length(nam001')
% % for j=1:length(theta001')
% % 
% %    I1(j,i)=IeN(SK,theta001(j),nam001(i)); 
% %    I2(j,i)=IeE(SK,theta001(j),nam001(i));
% %     
% % end
% % end
% 
% nam02=nam0001.*cosd(xzj)-theta0001.*sind(xzj);
% theta02=theta0001.*cosd(xzj)+nam0001.*sind(xzj);
% % I01=I1.*cosd(xzj)-I2.*sind(xzj);
% % I02=I2.*cosd(xzj)+I1.*sind(xzj);
% 
% % quiver(nam02,theta02,I02,I01,1);%��Դ
% contourf(nam02,theta02,PSI,'ShowText','on');
% colormap(jet)
% qhh=colorbar('FontSize',8);
% set(get(qhh,'Title'),'string','kA');
% 
% % hold on
% % quiver(34,-34,1/2^0.5,1/2^0.5,2,'b');
% axis equal
%==================================================
%����ͼƬ
as=20;
px=deg2rad([0:0.1:360]);
py=deg2rad([21 10 90]);
[px,py]=meshgrid(px,py/as);
[px,py]=pol2cart(px,py);
px=rad2deg(px);py=rad2deg(py);
hold on
plot(px(1,:),py(1,:),'k',"LineStyle",'-',"LineWidth",0.1);
plot(px(2,:),py(2,:),'k',"LineStyle",'--',"LineWidth",0.1);
% plot(px(3,:),py(3,:),'k',"LineWidth",0.2);
plot([0,0],[21/as,-21/as],'k',"LineStyle",'--',"LineWidth",0.1);
plot([-21/as,21/as],[0,0],'k',"LineStyle",'--',"LineWidth",0.1);
text(21/as,0,'12','FontSize',8);
text(-1/as,22/as,'18','FontSize',8);
text(-22.5/as,0,'00','FontSize',8);
text(-1/as,-22/as,'06','FontSize',8 );
text(1/as,1/as,'90��N','FontSize',8 );
text(8/as,8/as,'70��N','FontSize',8 );
text(16/as,16/as,'50��N','FontSize',8 );
% text(36/as,-34/as,'1A/m','FontSize',6,'Fontname','times new Roman');
% aaa=num2str(SK);%

text(-20/as,18/as,'2018-02-02','FontSize',8);
text(-20/as,16/as,'01:30 UT','FontSize',8);
text(-20/as,20/as,'Divergence-free','FontSize',8);
% % text(-40/as,40/as,'Curl-free','FontSize',8,'Fontname','times new Roman');
text(11/as,-19/as,['Maximun=',MAX,'kA'],'FontSize',8);
text(11/as,-21/as,['Minimun=' MIN 'kA'],'FontSize',8);
text(19/as,19/as,'(g)','FontSize',8);


% text(-40/as,40/as,datestr(time),'FontSize',8,'Fontname','times new Roman');

text(-1/as,-24/as,'MLT','FontSize',8);
axis off
axis equal
hold off










