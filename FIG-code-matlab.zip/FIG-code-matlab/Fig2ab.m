clc
clear
clearvars
%==================================
%===============================================================
%SYM-H
pp=fopen('SYM-H.txt');
wj=textscan(pp,'%s','delimiter','\t');
sj=char(wj{1,1});
fclose(pp);
for i=2176:4335
symh(i-2175,1)=str2double(sj(i,63:70));
end
%=================================================================
%AE
pp00=fopen('AE.txt');
wj00=textscan(pp00,'%s','delimiter','\t');
sj00=char(wj00{1,1});
fclose(pp00);
for i=2176:4335
ae(i-2175,1)=str2double(sj00(i,31:41));
end
%================================================================


%===============================================================
TP=tiledlayout(3,2);
TP.TileSpacing = 'compact';
TP.Padding = 'compact';
%=======================================================
nexttile([1 2])
plot(ae,'k');
axis([0 2200 0 500]);
hold on
xxxls=2160;
xxy1=[0;500];
xxx1=[xxxls*6/36;xxxls*15/36;xxxls*23.5/36;xxxls*28.5/36];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');
plot([xxx1(3) xxx1(3)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(4) xxx1(4)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(3),xxx1(4),xxx1(4),xxx1(3)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

plot(427,285,'r.','MarkerSize', 15)
plot(572,410,'r.','MarkerSize', 15)
plot(810,200,'r.','MarkerSize', 15)

hold off
xticks(0:fix((2160)/6):2160)
set(gca,'xticklabel',[] )
ylabel({'AE';'[nT]'})
% text(1767-1440+10,900,'t2','FontSize',8 )
% text(148+10,900,'t1','FontSize',8)
% text(896+10,900,'t3','FontSize',8 )
text(30,470,'(a)' )
text(427,315,'19:07','Color','red','FontSize',10 )
text(572,440,'21:32','Color','red','FontSize',10 )
text(810,230,'01:30','Color','red','FontSize',10 )
text(2160*25/36,330,{'Upstream','energetic','     ion','   event'},'Color','b','FontSize',10)
%=======================================================================
nexttile([2 2])
plot(symh,'k');
axis([0 2200 -16 10]);
hold on
xxxls=2160;
xxy1=[-16;10];
xxx1=[xxxls*23.5/36;xxxls*28.5/36];
plot([xxx1(1) xxx1(1)], [xxy1(1) xxy1(2)],'k--')
plot([xxx1(2) xxx1(2)], [xxy1(1) xxy1(2)],'k--')
patch([xxx1(1),xxx1(2),xxx1(2),xxx1(1)],[xxy1(1),xxy1(1),xxy1(2),xxy1(2)],'k','FaceAlpha','0.1','EdgeColor','none');

hold off
set(gca,'xticklabel',[] )
text(30,8.5,'(b)')
ylabel({'SYM-H';'[nT]'} )
xticks(0:fix((2160)/6):2160)
xticklabels({'Feb 01 12:00','18:00','Feb 02 00:00','06:00','12:00','18:00','24:00'})
xlabel('Time (UT:hhmm) on Feb 01-02 2018' )
%==============================================================











