clc
clear
clearvars
%==================================
X1h=(50:1:800);

% TP=tiledlayout(3,1);
% TP.TileSpacing = 'compact';
% TP.Padding = 'compact';
% 
% nexttile
% plot(X1h,100.*((2.6464e+15).*X1h.^(-5.3580))./((5.4261e+03).*exp(-0.0080.*X1h)+(1.6808e+05).*exp(-0.0183.*X1h)+(2.6464e+15).*X1h.^(-5.3580)),'r-')
% hold on
% plot(X1h,100.*((3.4324e+16).*X1h.^(-6.0281))./((7.3218e+03).*exp(-0.0094.*X1h)+(1.1976e+05).*exp(-0.0221.*X1h)+(3.4324e+16).*X1h.^(-6.0281)),'b-')
% plot(X1h,100.*((2.1883e+15).*X1h.^(-5.0980))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'k-')
% hold off
% xticks(0:100:800)
% xticklabels([])
% set(gca,'xminortick','on','FontSize',8,'Fontname','times new Roman');
% set(gca,'yminortick','on');
% set(gca,'ytick',[0 20  60  100]);
% axis([0 800 0 100]);
% ylabel({'Flux Ratio';'Proton';'[%]'},'FontSize',8,'Fontname','times new Roman');
% leg2=legend({'11:00~13:00','15:00~17:00','19:00~21:00'}, 'Location', 'NorthEast','FontSize',8,'Fontname','times new Roman');
% leg2.ItemTokenSize = [10,1];
% text(15,90,'(a)','Color','k','FontSize',8,'Fontname','times new Roman')
% 
% %=============================
% %TP-5/4
% nexttile
% plot(X1h,100.*((1.6808e+05).*exp(-0.0183.*X1h))./((5.4261e+03).*exp(-0.0080.*X1h)+(1.6808e+05).*exp(-0.0183.*X1h)+(2.6464e+15).*X1h.^(-5.3580)),'r-')
% hold on
% plot(X1h,100.*((1.1976e+05).*exp(-0.0221.*X1h))./((7.3218e+03).*exp(-0.0094.*X1h)+(1.1976e+05).*exp(-0.0221.*X1h)+(3.4324e+16).*X1h.^(-6.0281)),'b-')
% plot(X1h,100.*((1.8819e+05).*exp(-0.0150.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'k-')
% plot([200,200],[0,100],'k--')
% hold off
% xticks(0:100:800)
% xticklabels([])
% set(gca,'xminortick','on','FontSize',8,'Fontname','times new Roman');
% set(gca,'yminortick','on');
% set(gca,'ytick',[0 20  60  100]);
% axis([0 800 0 100]);
% ylabel({'Flux Ratio';'Helium';'[%]'},'FontSize',8,'Fontname','times new Roman');
% leg2=legend({'11:00~13:00','15:00~17:00','19:00~21:00'}, 'Location', 'NorthEast','FontSize',8,'Fontname','times new Roman');
% leg2.ItemTokenSize = [10,1];
% text(15,90,'(b)','Color','k','FontSize',8,'Fontname','times new Roman')
% text(215,80,'200keV','Color','k','FontSize',8,'Fontname','times new Roman')
% %=============================
% %TP-6/4
% nexttile
% plot(X1h,100.*((5.4261e+03).*exp(-0.0080.*X1h))./((5.4261e+03).*exp(-0.0080.*X1h)+(1.6808e+05).*exp(-0.0183.*X1h)+(2.6464e+15).*X1h.^(-5.3580)),'r-')
% hold on
% plot(X1h,100.*((7.3218e+03).*exp(-0.0094.*X1h))./((7.3218e+03).*exp(-0.0094.*X1h)+(1.1976e+05).*exp(-0.0221.*X1h)+(3.4324e+16).*X1h.^(-6.0281)),'b-')
% plot(X1h,100.*((1.1043e+04).*exp(-0.0069.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'k-')
% hold off
% xticks(0:100:800)
% set(gca,'xminortick','on','FontSize',8,'Fontname','times new Roman');
% set(gca,'yminortick','on');
% set(gca,'ytick',[ 20  60  100]);
% xticklabels({'0','100','200','300','400','500','600','700','800'})
% axis([0 800 0 100]);
% ylabel({'Flux Ratio';'Oxygen';'[%]'},'FontSize',8,'Fontname','times new Roman');
% leg2=legend({'11:00~13:00','15:00~17:00','19:00~21:00'}, 'Location', 'SouthEast','FontSize',8,'Fontname','times new Roman');
% leg2.ItemTokenSize = [10,1];
% text(15,90,'(c)','Color','k','FontSize',8,'Fontname','times new Roman')
% 
% %====================================================================
% xlabel(TP,'[keV]','FontSize',8,'Fontname','times new Roman')


plot(X1h,100.*((2.1883e+15).*X1h.^(-5.0980))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'r-','LineWidth',2)
hold on
plot(X1h,100.*((1.8819e+05).*exp(-0.0150.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'b-','LineWidth',2)
plot(X1h,100.*((1.1043e+04).*exp(-0.0069.*X1h))./((1.1043e+04).*exp(-0.0069.*X1h)+(1.8819e+05).*exp(-0.0150.*X1h)+(2.1883e+15).*X1h.^(-5.0980)),'k-','LineWidth',2)
plot([200,200],[0,100],'k--')
plot([100,100],[0,100],'k--')
hold off
xticks(0:100:800)
set(gca,'xminortick','on','FontSize',8,'Fontname','times new Roman');
set(gca,'yminortick','on');
set(gca,'ytick',[ 20  60  100]);
xticklabels({'0','100','200','300','400','500','600','700','800'})
axis([0 800 0 100]);
ylabel({'Flux Ratio';'[%]'},'FontSize',8,'Fontname','times new Roman');
leg2=legend({'H','He','O'}, 'FontSize',8,'Fontname','times new Roman');
leg2.ItemTokenSize = [10,1];
xlabel('[keV]','FontSize',8,'Fontname','times new Roman')

















