clc
clear
clearvars
%==================================
[ST,N] = readSTT(1);
STSP=ST(1:7,2:3);
STNP=ST(97:115,2:3);

STNP=cell2mat(STNP);
STSP=cell2mat(STSP);

theta=90-STNP(1:19,1);
nam=STNP(1:19,2);

% sz=10;
% polarscatter(nam,theta,sz,'filled','red');
% 
% hold on 
% 
% theta1=[];
% theta7=[];
% theta1(1:20,1)=9;
% theta2=theta1+9;
% theta3=theta2+9;
% theta4=theta3+9;
% theta5=theta4+9;
% theta7(1:20,1)=90;
% nam2=pi/10:pi/10:2*pi;
% nam22=nam2';
% sz2=5;
% polarscatter(nam22,theta1,sz2,'filled','blue');
% hold on
% polarscatter(nam22,theta2,sz2,'filled','blue');
% hold on
% polarscatter(nam22,theta3,sz2,'filled','blue');
% hold on
% polarscatter(nam22,theta4,sz2,'filled','blue');
% hold on
% polarscatter(nam22,theta5,sz2,'filled','blue');
% hold on
% sz3=1;
% polarscatter(nam22,theta7,sz3,'filled','white');
% hold off


% [nam01,theta01]=meshgrid(nam,theta);
nam001=(theta).*cosd(nam);
theta001=(theta).*sind(nam);
sz=20;
scatter(nam001,theta001,sz,'filled','blue');
axis equal
%����ͼƬ
px=deg2rad([0:0.1:360]);
py=deg2rad([30 20 10 30]);
[px,py]=meshgrid(px,py);
[px,py]=pol2cart(px,py);
px=rad2deg(px);py=rad2deg(py);
hold on
plot(px(1,:),py(1,:),'k',"LineStyle",'--',"LineWidth",1);
plot(px(2,:),py(2,:),'k',"LineStyle",'--',"LineWidth",1);
plot(px(3,:),py(3,:),'k',"LineStyle",'--',"LineWidth",1);
plot(px(4,:),py(4,:),'k',"LineStyle",'-',"LineWidth",1);
% plot(px(3,:),py(3,:),'k',"LineWidth",0.2);
plot([0,0],[30,-30],'k',"LineStyle",'--',"LineWidth",1);
plot([-30,30],[0,0],'k',"LineStyle",'--',"LineWidth",1);

text(31,0,'0��','FontSize',6,'Fontname','times new Roman');
text(-2,32,'90��','FontSize',6,'Fontname','times new Roman');
text(-35,0,'180��','FontSize',6,'Fontname','times new Roman');
text(-2,-32,'270��','FontSize',6,'Fontname','times new Roman');
text(1,2,'90��N','FontSize',6,'Fontname','times new Roman');
text(8,8,'80��N','FontSize',6,'Fontname','times new Roman');
text(15,15,'70��N','FontSize',6,'Fontname','times new Roman');
text(22,22,'60��N','FontSize',6,'Fontname','times new Roman');
% text(74,54,'0��','FontSize',6,'Fontname','times new Roman');
% text(-2,-66,'MLT','FontSize',7);
% set(gca,'Fontname','times new Roman');

axis off





